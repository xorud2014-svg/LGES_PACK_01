#ifndef __MODULECONTROL_DEF_H__
#define __MODULECONTROL_DEF_H__

#include "HW_Addr_Cycler_SK_450V_200A_10A_90KW.h"

//sbc type
#define SBC_HS_6637							1
#define SBC_WEB_6580						2
#define SBC_HS_4020							3
#define SBC_WAFER_E669						4
#define SBC_WAFER_LX800						5
#define SBC_WAFER_MARK533					6
#define SBC_EM104_A5362						7
#define SBC_WAFER_MARK800					8

//test condition define
#define MAX_TEST_STEP         				100
//#define MAX_TEST_PATTERN					5 //default
#define MAX_TEST_PATTERN					20 //for LGC 081027 : sbc 128M->256M
//#define MAX_TEST_PATTERN					40 //for SKE 090312 : sbc 128M->256M
#define MAX_PATTERN_DATA					20001
#define MAX_COM_TEST_OBJECT					30
#define MAX_LOC_TEST_OBJECT					160
#define MAX_TEST_GRADE        				10
#define MAX_COM_FAULT_CODE					20
#define MAX_LOC_FAULT_CODE					200
#define MAX_AUX_FAULT_CODE					20
#define MAX_CAN_FAULT_CODE					20

//step type
#define STEP_IDLE							0
#define	STEP_CHARGE							1
#define	STEP_DISCHARGE						2
#define	STEP_REST							3
#define	STEP_OCV							4
#define STEP_Z								5
#define	STEP_END							6
#define STEP_CYCLE							7
#define STEP_LOOP							8
#define STEP_PATTERN						9

//cali type
#define CALI_IDLE							0
#define CALI_CHARGE							1
#define CALI_DISCHARGE						2

//step mode
#define MODE_IDLE							0
#define	MODE_CCCV							1
#define	MODE_CC								2
#define	MODE_CV								3
#define MODE_DC								4
#define MODE_AC								5
#define MODE_CP								6
#define MODE_CCP							7
#define MODE_CR								8

//value_rate item
#define VALUE_RATE_ITEM_IDLE				0
#define VALUE_RATE_ITEM_AMPARE_HOUR			1
#define VALUE_RATE_ITEM_WATT_HOUR			2

//grade item
#define GRADE_ITEN_IDLE						0
#define GRADE_ITEM_V						1
#define GRADE_ITEM_AMPARE_HOUR				2
#define GRADE_ITEM_Z						3
#define GRADE_ITEM_CAPACITANCE				4

//capacity type
#define CAPACITY_AMPARE_HOURS				0
#define CAPACITY_CAPACITANCE				1

//range define
#define RANGE0								0 //range off
#define RANGE1								1
#define RANGE2								2
#define RANGE3								3
#define RANGE4								4

//operation type
#define OP_INDEPENDENT						0
#define OP_PARALLEL							1

//save flag
#define SAVE_FLAG_MONITORING_DATA			0
#define SAVE_FLAG_SAVING_END				1
#define SAVE_FLAG_SAVING_TIME				2
#define SAVE_FLAG_SAVING_DELTA_V			3
#define SAVE_FLAG_SAVING_DELTA_I			4
#define SAVE_FLAG_SAVING_DELTA_TEMP			5
#define SAVE_FLAG_SAVING_DELTA_P			6
#define SAVE_FLAG_SAVING_ETC				7

//attribute list
#define ATTR_IDLE							0
#define ATTR_CHECK1_START					1	//1step charge
#define ATTR_CHECK1_1						2
#define ATTR_CHECK1_2						3
#define ATTR_CHECK1_3						4
#define ATTR_CHECK1_4						5
#define ATTR_CHECK1_5						6
#define ATTR_CHECK1_6						7
#define ATTR_CHECK1_7						8
#define ATTR_CHECK1_8						9
#define ATTR_CHECK1_9						10
#define ATTR_CHECK1_10						11
#define ATTR_CHECK1_END						12
#define ATTR_DC1_START						21	//1step discharge
#define ATTR_DC1_1							22
#define ATTR_DC1_2							23
#define ATTR_DC1_3							24
#define ATTR_DC1_4							25
#define ATTR_DC1_5							26
#define ATTR_DC1_6							27
#define ATTR_DC1_7							28
#define ATTR_DC1_8							29
#define ATTR_DC1_9							30
#define ATTR_DC1_10							31
#define ATTR_DC1_END						32
#define ATTR_DC2_START						41	//discharge -> rest -> discharge
#define ATTR_DC2_1							42
#define ATTR_DC2_2							43
#define ATTR_DC2_3							44
#define ATTR_DC2_4							45
#define ATTR_DC2_5							46
#define ATTR_DC2_6							47
#define ATTR_DC2_7							48
#define ATTR_DC2_8							49
#define ATTR_DC2_9							50
#define ATTR_DC2_10							51
#define ATTR_DC2_END						52
#define ATTR_DC3_START						61	//chargge -> rest -> charge
#define ATTR_DC3_1							62
#define ATTR_DC3_2							63
#define ATTR_DC3_3							64
#define ATTR_DC3_4							65
#define ATTR_DC3_5							66
#define ATTR_DC3_6							67
#define ATTR_DC3_7							68
#define ATTR_DC3_8							69
#define ATTR_DC3_9							70
#define ATTR_DC3_10							71
#define ATTR_DC3_END						72
#define ATTR_SUB_START						81 //multi step charge/discharge
#define ATTR_SUB_1							82
#define ATTR_SUB_2							83
#define ATTR_SUB_3							84
#define ATTR_SUB_4							85
#define ATTR_SUB_5							86
#define ATTR_SUB_6							87
#define ATTR_SUB_7							88
#define ATTR_SUB_8							89
#define ATTR_SUB_9							90
#define ATTR_SUB_10							91
#define ATTR_SUB_END						92
#define ATTR_TOTAL_CHECK					100 //total check

//common object index
#define IDX_COM_OBJ_TOTAL_STEP				0 //common test conditon
#define IDX_COM_OBJ_ATTRIBUTE_COUNT			1
#define IDX_COM_OBJ_FAULT_HW_UPPER_V		5 //hard fault condition
#define IDX_COM_OBJ_FAULT_HW_LOWER_V		6
#define IDX_COM_OBJ_FAULT_HW_UPPER_I		7
#define IDX_COM_OBJ_FAULT_HW_LOWER_I		8
#define IDX_COM_OBJ_FAULT_HW_UPPER_TEMP		9
#define IDX_COM_OBJ_FAULT_HW_LOWER_TEMP		10
#define IDX_COM_OBJ_FAULT_UPPER_V			15 //soft fault condition
#define IDX_COM_OBJ_FAULT_LOWER_V			16
#define IDX_COM_OBJ_FAULT_UPPER_I			17
#define IDX_COM_OBJ_FAULT_LOWER_I			18
#define IDX_COM_OBJ_FAULT_UPPER_AMPARE_HOUR	19
#define IDX_COM_OBJ_FAULT_LOWER_AMPARE_HOUR	20
#define IDX_COM_OBJ_FAULT_UPPER_TEMP		21
#define IDX_COM_OBJ_FAULT_LOWER_TEMP		22
#define IDX_COM_OBJ_FAULT_MAX_CH			23
//#define IDX_COM_OBJ_FAULT_UPPER_CAPACITANCE	24
//#define IDX_COM_OBJ_FAULT_LOWER_CAPACITANCE	25
#define IDX_COM_OBJ_FAULT_UPPER_WATT_HOUR	24
#define IDX_COM_OBJ_FAULT_LOWER_WATT_HOUR	25

//local object index
#define IDX_LOC_OBJ_CLIENT_STEP_NO			0 //step condition
#define IDX_LOC_OBJ_STEP_NO					1
#define IDX_LOC_OBJ_TYPE					2
#define IDX_LOC_OBJ_MODE					3
#define IDX_LOC_OBJ_ATTRIBUTE				4
#define IDX_LOC_OBJ_REF_V					5
#define IDX_LOC_OBJ_REF_I					6
#define IDX_LOC_OBJ_REF_P					7
#define IDX_LOC_OBJ_RANGE_V					8
#define IDX_LOC_OBJ_RANGE_I					9
#define IDX_LOC_OBJ_TEST_END				10
#define IDX_LOC_OBJ_TOTAL_SUB_STEP			11
#define IDX_LOC_OBJ_CAPACITANCE_V1			12
#define IDX_LOC_OBJ_CAPACITANCE_V2			13
#define IDX_LOC_OBJ_Z_T1					14
#define IDX_LOC_OBJ_Z_T2					15
#define IDX_LOC_OBJ_LC_T1					16
#define IDX_LOC_OBJ_LC_T2					17
#define IDX_LOC_OBJ_REF_R					18
#define IDX_LOC_OBJ_PATTERN_INDEX			19
#define IDX_LOC_OBJ_REF_V2					20 //for discharge cv ref at pattern
#define IDX_LOC_OBJ_SAVE_DELTA_T			30 //save condition
#define IDX_LOC_OBJ_SAVE_DELTA_V			31
#define IDX_LOC_OBJ_SAVE_DELTA_I			32
#define IDX_LOC_OBJ_SAVE_DELTA_TEMP			33
#define IDX_LOC_OBJ_SAVE_DELTA_P			34

#define IDX_LOC_OBJ_END_CONDITION_START		40 //end condition start
#define IDX_LOC_OBJ_END_SUM_AMPARE_HOUR		40
#define IDX_LOC_OBJ_END_SUM_WATT_HOUR		41

#define IDX_LOC_OBJ_END_V_UPPER				42
#define IDX_LOC_OBJ_END_V_UPPER_BRANCH		43
#define IDX_LOC_OBJ_END_V_LOWER				44
#define IDX_LOC_OBJ_END_V_LOWER_BRANCH		45
#define IDX_LOC_OBJ_END_TIME				46
#define IDX_LOC_OBJ_END_TIME_BRANCH			47
#define IDX_LOC_OBJ_END_CV_TIME				48
#define IDX_LOC_OBJ_END_CV_TIME_BRANCH		49
#define IDX_LOC_OBJ_END_AMPARE_HOUR			50
#define IDX_LOC_OBJ_END_AMPARE_HOUR_BRANCH	51
#define IDX_LOC_OBJ_END_WATT_HOUR			52
#define IDX_LOC_OBJ_END_WATT_HOUR_BRANCH	53
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE	54
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE_BRANCH	55
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE_COMPARE	56
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE		57
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE_BRANCH	58
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE_COMPARE	59

#define IDX_LOC_OBJ_END_CYCLE_COUNT			60
#define IDX_LOC_OBJ_END_CYCLE_COUNT_BRANCH	61
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT	62
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT_BRANCH	63
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT_COMPARE	64
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT		65
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT_BRANCH	66
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT_COMPARE	67

#define IDX_LOC_OBJ_END_I					68
#define IDX_LOC_OBJ_END_P					69
#define IDX_LOC_OBJ_END_DELTA_V				70
#define IDX_LOC_OBJ_END_DELTA_I				71

#define IDX_LOC_OBJ_END_CAN_V_UPPER			72 //kjg_update 090304 0x1008
#define IDX_LOC_OBJ_END_CAN_V_UPPER_BRANCH	73
#define IDX_LOC_OBJ_END_CAN_V_LOWER			74
#define IDX_LOC_OBJ_END_CAN_V_LOWER_BRANCH	75
#define IDX_LOC_OBJ_END_CAN_TEMP_UPPER		76
#define IDX_LOC_OBJ_END_CAN_TEMP_UPPER_BRANCH	77
#define IDX_LOC_OBJ_END_CAN_TEMP_LOWER		78
#define IDX_LOC_OBJ_END_CAN_TEMP_LOWER_BRANCH	79
#define IDX_LOC_OBJ_END_CAN_SOC_UPPER		80
#define IDX_LOC_OBJ_END_CAN_SOC_UPPER_BRANCH	81
#define IDX_LOC_OBJ_END_CAN_SOC_LOWER		82
#define IDX_LOC_OBJ_END_CAN_SOC_LOWER_BRANCH	83
#define IDX_LOC_OBJ_END_CAN_FAULT			84
#define IDX_LOC_OBJ_END_CAN_FAULT_BRANCH	85

#define IDX_LOC_OBJ_END_AUX_V_UPPER			86
#define IDX_LOC_OBJ_END_AUX_V_UPPER_BRANCH	87
#define IDX_LOC_OBJ_END_AUX_V_LOWER			88
#define IDX_LOC_OBJ_END_AUX_V_LOWER_BRANCH	89
#define IDX_LOC_OBJ_END_AUX_TEMP_UPPER		90
#define IDX_LOC_OBJ_END_AUX_TEMP_UPPER_BRANCH	91
#define IDX_LOC_OBJ_END_AUX_TEMP_LOWER		92
#define IDX_LOC_OBJ_END_AUX_TEMP_LOWER_BRANCH	93

/*kjgw #define IDX_LOC_OBJ_STOP_V_UPPER			51
#define IDX_LOC_OBJ_STOP_V_LOWER			51
#define IDX_LOC_OBJ_STOP_I					52
#define IDX_LOC_OBJ_STOP_T					53
#define IDX_LOC_OBJ_STOP_C					54
#define IDX_LOC_OBJ_STOP_P					55
#define IDX_LOC_OBJ_STOP_WATT_HOUR			56*/
#define IDX_LOC_OBJ_END_CONDITION_END		99 //end condition end 

#define IDX_LOC_OBJ_FAULT_HW_UPPER_V		100 //hard fault condition
#define IDX_LOC_OBJ_FAULT_HW_LOWER_V		101
#define IDX_LOC_OBJ_FAULT_HW_UPPER_I		102
#define IDX_LOC_OBJ_FAULT_HW_LOWER_I		103
#define IDX_LOC_OBJ_FAULT_HW_UPPER_TEMP		104
#define IDX_LOC_OBJ_FAULT_HW_LOWER_TEMP		105
#define IDX_LOC_OBJ_FAULT_UPPER_OCV			110 //soft fault condition
#define IDX_LOC_OBJ_FAULT_LOWER_OCV			111
#define IDX_LOC_OBJ_FAULT_UPPER_V			112
#define IDX_LOC_OBJ_FAULT_LOWER_V			113
#define IDX_LOC_OBJ_FAULT_UPPER_I			114
#define IDX_LOC_OBJ_FAULT_LOWER_I			115
#define IDX_LOC_OBJ_FAULT_UPPER_AMPARE_HOUR	116
#define IDX_LOC_OBJ_FAULT_LOWER_AMPARE_HOUR	117
#define IDX_LOC_OBJ_FAULT_UPPER_WATT_HOUR	118
#define IDX_LOC_OBJ_FAULT_LOWER_WATT_HOUR	119
#define IDX_LOC_OBJ_FAULT_UPPER_Z			120
#define IDX_LOC_OBJ_FAULT_LOWER_Z			121

#define IDX_LOC_OBJ_FAULT_COMP_V_T1			122
#define IDX_LOC_OBJ_FAULT_COMP_V_T2			123
#define IDX_LOC_OBJ_FAULT_COMP_V_T3			124
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V1		125
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V2		126
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V3		127
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V1		128
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V2		129
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V3		130
#define IDX_LOC_OBJ_FAULT_COMP_I_T1			131
#define IDX_LOC_OBJ_FAULT_COMP_I_T2			132
#define IDX_LOC_OBJ_FAULT_COMP_I_T3			133
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I1		134
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I2		135
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I3		136
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I1		137
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I2		138
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I3		139

#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_V_T	140
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_V		141
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_V_T	142
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_V		143
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_I_T	144
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_I		145
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_I_T	146
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_I		147
#define IDX_LOC_OBJ_FAULT_UPPER_TEMP		148
#define IDX_LOC_OBJ_FAULT_LOWER_TEMP		149
#define IDX_LOC_OBJ_FAULT_DELTA_TEMP		150
#define IDX_LOC_OBJ_FAULT_UPPER_CAPACITANCE	151
#define IDX_LOC_OBJ_FAULT_LOWER_CAPACITANCE	152
/*#define IDX_LOC_OBJ_FAULT_ACC_CYCLE			153
#define IDX_LOC_OBJ_FAULT_ACC_CYCLE_ID		154
#define IDX_LOC_OBJ_FAULT_MULTI_CYCLE		155
#define IDX_LOC_OBJ_FAULT_MULTI_CYCLE_ID	156*/

//module state
#define	M_IDLE								0
#define M_STANDBY							1
#define M_RUN								2
#define M_PAUSE								3
#define M_CALI								4
#define M_FAIL								5

//group state
#define G_IDLE								0
#define G_STANDBY							1
#define G_RUN								2
#define G_PAUSE								3
#define G_CALI								4

//board state
#define B_IDLE								0
#define B_STANDBY							1
#define B_RUN								2
#define B_PAUSE								3
#define B_CALI								4

//channel state
#define	C_IDLE								0
#define	C_STANDBY							1
#define C_RUN								2
#define C_PAUSE								3
#define C_CALI								4
#define C_FAULT								5

//semi switch state
#define SEMI_IDLE							0
#define SEMI_I_P							1
#define SEMI_I_N							2

//module signal
#define M_SIG_EXIT_PHASE					0
#define M_SIG_EXIT_TYPE						1
/*kjgw #define M_SIG_POWER_OFF_CLR			1
#define M_SIG_UPS_OFF						2
#define M_SIG_SELFTEST_START				3*/

#define M_SIG_LAMP_RUN						21
#define M_SIG_LAMP_STOP						22
#define M_SIG_CALI_RELAY					23
#define M_SIG_REMOTE_SMPS1					24
#define M_SIG_RUN_LED						25
#define M_SIG_FAN_RELAY						26
#define M_SIG_POWER_OFF						27
#define M_SIG_SMPS_FAULT					28
#define M_SIG_OT_FAULT						29
#define M_SIG_SEND_ERROR_CODE				30
#define M_SIG_TEST_SEND_SAVE_DATA			31
#define M_SIG_CALI_RELAY2					32

//group signal
#define G_SIG_CMD_RUN						0
#define G_SIG_CMD_STOP						1
#define G_SIG_CMD_PAUSE						2
#define G_SIG_CMD_CONTINUE					3
#define G_SIG_CMD_NEXT_STEP					4
#define G_SIG_CMD_CLEAR						5
#define G_SIG_SAVED_FILE_DELETE_COMPLETE	6
#define G_SIG_DATA_SAVE_COMPLETE			7
#define G_SIG_CONTACT_COMPLETE				8
#define G_SIG_DISCONTACT_COMPLETE			9
#define G_SIG_JIG_FAIL						10
#define G_SIG_NEXT_STEP_EXIST				11
#define G_SIG_EXIT_PHASE					12
#define G_SIG_CMD_RESET						13
#define G_SIG_V_CMD_OUTPUT					14
#define G_SIG_I_CMD_OUTPUT					15
#define G_SIG_NET_CHECK						16

//board signal
#define B_SIG_CMD_RUN						0
#define B_SIG_CMD_STOP						1
#define B_SIG_CMD_PAUSE						2
#define B_SIG_CMD_CONTINUE					3
#define B_SIG_CMD_NEXT_STEP					4
#define B_SIG_CMD_RESET						5
#define B_SIG_RUN							6
#define B_SIG_STOP							7
#define B_SIG_V_RANGE_SELECT				8
#define B_SIG_I_RANGE_SELECT				9
#define B_SIG_V_CMD_OUTPUT					10
#define B_SIG_I_CMD_OUTPUT					11
#define B_SIG_CHECK_PAUSE					12
#define B_SIG_RESET							13

#define B_SIG_RESET_LATCHED					20
#define B_SIG_HW_FAULT_CLEAR				21

//channel signal
#define C_SIG_CMD_RUN						0
#define C_SIG_CMD_STOP						1
#define C_SIG_CMD_PAUSE						2
#define C_SIG_CMD_CONTINUE					3
#define C_SIG_CMD_NEXT_STEP					4
#define C_SIG_CMD_RESET						5
#define C_SIG_CMD_CHECK						6
#define C_SIG_CMD_CALI						7
#define C_SIG_CMD_GOTO_STEP					8
#define C_SIG_MODULE_FAULT					9

//#define C_SIG_CHECK_PAUSE					10
#define C_SIG_AUX_DAV						11
#define C_SIG_AUX_DAI						12
#define C_SIG_TEST_CONDITION_RCV			13
#define C_SIG_RESET							15
#define C_SIG_SAVED_FILE_DELETE				16
#define C_SIG_CHECK_DATA_SAVE				17
#define C_SIG_METER_REPLY					20
#define C_SIG_METER_ERROR					21
#define C_SIG_FAULT_HW_OT					22
#define C_SIG_FAULT_M_PS					23
#define C_SIG_V_CMD_OUTPUT					25
#define C_SIG_I_CMD_OUTPUT					26
#define C_SIG_RUN_RELAY_ON					27
#define C_SIG_RUN_RELAY_OFF					28

#define C_SIG_CALI_NORMAL					30
#define C_SIG_CALI_CHECK					31
#define C_SIG_CALI_POINT					32
#define C_SIG_CALI_PHASE					33
#define C_SIG_CALI_NORMAL_RESULT_SAVED		34
#define C_SIG_CALI_CHECK_RESULT_SAVED		35

#define C_SIG_OUT_SWITCH					40
#define C_SIG_SEMI_SWITCH					41
#define C_SIG_SELECTED_RANGE_I				42
#define C_SIG_C_D_SELECT					43
#define C_SIG_SMPS_FAULT					44
#define C_SIG_FAULT_M_POWER_SWITCH			45
#define C_SIG_FAULT_M_EMG_SWITCH			46
#define C_SIG_FAULT_M_AC_POWER				47
#define C_SIG_FAULT_M_UPS_BATTERY			48
#define C_SIG_USER_CONTROL					49

//code
#define M_CD_NONE							0
#define M_CD_FAULT_AC_POWER_SHORT			1	
#define M_CD_FAULT_AC_POWER_LONG			2
#define M_CD_FAULT_UPS_BATTERY				3
#define M_CD_FAULT_MAIN_EMG_SWITCH			4
#define M_CD_FAULT_SUB_EMG_SWITCH			5
#define M_CD_FAULT_CONTROL_PS				6
#define M_CD_FAULT_OT						7	
#define M_CD_FAULT_WARNING_POWER_OFF		8
#define M_CD_FAULT_NORMAL_POWER_OFF			9
#define M_CD_FAULT_FORCE_POWER_OFF			10
#define M_CD_FAULT_NORMAL_TERMINAL_QUIT		11
#define M_CD_FAULT_FORCE_TERMINAL_QUIT		12
#define M_CD_FAULT_NORMAL_TERMINAL_HALT		13
#define M_CD_FAULT_FORCE_TERMINAL_HALT		14
#define M_CD_FAULT_CPU_WATCHDOG				15
#define M_CD_FAULT_CALI_METER_COMM_ERROR	16
#define M_CD_FAULT_CALIBRATOR_COMM_ERROR	17
#define M_CD_FAULT_FUSE						18
#define M_CD_FAULT_UPPER_VOLTAGE			19
#define M_CD_FAULT_LOWER_VOLTAGE			20
#define M_CD_FAULT_MAIN_PS					21

#define G_CD_NONE							0
#define G_CD_FAULT_UPPER_VOLTAGE			50
#define G_CD_FAULT_UPPER_CURRENT			51
#define G_CD_FAULT_RUN_TIME_OVER			52
#define G_CD_FAULT_DATASAVE_PROCESS_ERROR	53
#define G_CD_FAULT_ADC						54
#define G_CD_FAULT_OT						55
/*kjgw #define G_CD_FAULT_JIG_ACTIVE_ERROR		55
#define G_CD_FAULT_JIG_TRAY_ERROR			56
#define G_CD_FAULT_JIG_SMOKE_ERROR			57
#define G_CD_FAULT_JIG_TEMP_ERROR			58
#define G_CD_FAULT_JIG_GAS_ERROR			59
#define G_CD_FAULT_JIG_DOOR_ERROR			60
#define G_CD_FAULT_JIG_AIR_PRESS_ERROR		61
#define G_CD_FAULT_JIG_STACKER_ERROR		62*/

#define B_CD_NONE							0
#define B_CD_FAULT_OT						100
#define B_CD_FAULT_ADC						101

#define C_CD_NONE							0
#define C_CD_COM_START						120 //common code
#define C_CD_COM_FAULT_HW_UPPER_V			120
#define C_CD_COM_FAULT_HW_LOWER_V			121
#define C_CD_COM_FAULT_HW_UPPER_I			122
#define C_CD_COM_FAULT_HW_LOWER_I			123
#define C_CD_COM_FAULT_HW_UPPER_TEMP		124
#define C_CD_COM_FAULT_HW_LOWER_TEMP		125
#define C_CD_COM_FAULT_UPPER_V				126
#define C_CD_COM_FAULT_LOWER_V				127
#define C_CD_COM_FAULT_UPPER_I				128
#define C_CD_COM_FAULT_LOWER_I				129
#define C_CD_COM_FAULT_UPPER_AMPARE_HOUR	130
#define C_CD_COM_FAULT_LOWER_AMPARE_HOUR	131
#define C_CD_COM_FAULT_UPPER_TEMP			132	//kjgw_s
#define C_CD_COM_FAULT_LOWER_TEMP			133
#define C_CD_COM_FAULT_UPPER_CAPACITANCE	134
#define C_CD_COM_FAULT_LOWER_CAPACITANCE	135	//kjgw_e
#define C_CD_COM_END						139
#define C_CD_END_START						140 //end code
#define C_CD_END_TIME						140
#define C_CD_END_V_UPPER					141
#define C_CD_END_I							142
#define C_CD_END_AMPARE_HOUR				143
#define C_CD_END_OCV						144
#define C_CD_END_STEP						145
#define C_CD_END_CHECK						146
#define C_CD_END_NEXT_STEP_CMD				147
#define C_CD_END_CYCLE						148
#define C_CD_END_LOOP						149
#define C_CD_END_Z							150
#define C_CD_END_DELTA_V					151
#define C_CD_END_DELTA_I					152
#define C_CD_END_VALUE_RATE_AMPARE_HOUR		153
#define C_CD_END_P							154
#define C_CD_END_WATT_HOUR					155
#define C_CD_END_V_LOWER					156
#define C_CD_END_CV_TIME					157
#define C_CD_END_GOTO_STEP_CMD				158
#define C_CD_END_STOP_CMD					159
#define C_CD_END_VALUE_RATE_WATT_HOUR		160
#define C_CD_END_SUM_AMPARE_HOUR			161
#define C_CD_END_SUM_WATT_HOUR				162
#define C_CD_END_END						169
#define C_CD_SAVE_START						170 //save code
#define C_CD_SAVE_DELTA_T					170
#define C_CD_SAVE_DELTA_V					171
#define C_CD_SAVE_DELTA_I					172
#define C_CD_SAVE_DELTA_TEMP				173
#define C_CD_SAVE_DELTA_P					174
#define C_CD_SAVE_END						179
#define C_CD_FAULT_HARD_START				180	//hard fault code
#define C_CD_FAULT_HW_UPPER_V				180
#define C_CD_FAULT_HW_LOWER_V				181
#define C_CD_FAULT_HW_UPPER_I				182
#define C_CD_FAULT_HW_LOWER_I				183
#define C_CD_FAULT_HW_OT					184
#define C_CD_FAULT_CHANNEL_PS				185
#define C_CD_FAULT_PS_OV					186
#define C_CD_FAULT_PS_OC					187
#define C_CD_FAULT_PS_DCOV					188
#define C_CD_FAULT_IN_FUSE					189
#define C_CD_FAULT_OUT_FUSE					190
#define C_CD_FAULT_HARD_END					199
#define C_CD_FAULT_EXTERNAL_START			200 //external fault code
#define C_CD_FAULT_M_CPU_WATCHDOG			200
#define C_CD_FAULT_M_AC_POWER				201
#define C_CD_FAULT_M_UPS_BATTERY			202
#define C_CD_FAULT_M_EMG_SWITCH				203
#define C_CD_FAULT_M_FORCE_POWER_SWITCH		204
#define C_CD_FAULT_M_FORCE_TERMINAL_HALT	205
#define C_CD_FAULT_M_FORCE_TERMINAL_QUIT	206
#define C_CD_FAULT_G_NETWORK_COMM			207
#define C_CD_FAULT_B_UPPER_TEMP				208
#define C_CD_FAULT_B_ADC					209
#define C_CD_FAULT_CONTROL_PS				210
#define C_CD_FAULT_EXTERNAL_END				219
#define C_CD_FAULT_CHECK_START				220 //check fault code
#define	C_CD_FAULT_CHECK_NG					220
#define C_CD_FAULT_CHECK_UPPER_OCV			221
#define C_CD_FAULT_CHECK_LOWER_OCV			222
#define C_CD_FAULT_CHECK_UPPER_V			223
#define C_CD_FAULT_CHECK_LOWER_V			224
#define C_CD_FAULT_CHECK_UPPER_I			225
#define C_CD_FAULT_CHECK_LOWER_I			226
#define C_CD_FAULT_CHECK_ERROR_NO			227
#define C_CD_FAULT_CHECK_ERROR_YES			228
#define C_CD_FAULT_CHECK_END				239
#define C_CD_FAULT_SOFT_START				240 //soft fault code
#define	C_CD_FAULT_UPPER_V					240
#define	C_CD_FAULT_LOWER_V					241
#define C_CD_FAULT_UPPER_DELTA_V			242
#define C_CD_FAULT_LOWER_DELTA_V			243
#define C_CD_FAULT_UPPER_COMP_V1			244
#define C_CD_FAULT_LOWER_COMP_V1			245
#define C_CD_FAULT_UPPER_COMP_V2			246
#define C_CD_FAULT_LOWER_COMP_V2			247
#define C_CD_FAULT_UPPER_COMP_V3			248
#define C_CD_FAULT_LOWER_COMP_V3			249
#define C_CD_FAULT_UPPER_OCV				250
#define C_CD_FAULT_LOWER_OCV				251
#define	C_CD_FAULT_UPPER_I					252
#define C_CD_FAULT_LOWER_I					253
#define C_CD_FAULT_UPPER_DELTA_I			254
#define C_CD_FAULT_LOWER_DELTA_I			255
#define C_CD_FAULT_UPPER_COMP_I1			256
#define C_CD_FAULT_LOWER_COMP_I1			257
#define C_CD_FAULT_UPPER_T					258
#define C_CD_FAULT_LOWER_T					259
#define C_CD_FAULT_UPPER_AMPARE_HOUR		260
#define	C_CD_FAULT_LOWER_AMPARE_HOUR		261
#define C_CD_FAULT_UPPER_DELTA_C			262
#define	C_CD_FAULT_LOWER_DELTA_C			263
#define C_CD_FAULT_UPPER_COMP_C				264
#define	C_CD_FAULT_LOWER_COMP_C				265
#define C_CD_FAULT_UPPER_Z					266
#define C_CD_FAULT_LOWER_Z					267
#define C_CD_FAULT_UPPER_TEMP				268
#define C_CD_FAULT_LOWER_TEMP				269
#define C_CD_FAULT_DELTA_TEMP				270
#define C_CD_FAULT_UPPER_COMP_I2			271
#define C_CD_FAULT_LOWER_COMP_I2			272
#define C_CD_FAULT_UPPER_COMP_I3			273
#define C_CD_FAULT_LOWER_COMP_I3			274
#define C_CD_FAULT_STOP_START				275 //fault_stop start
#define C_CD_FAULT_STOP_V					275
#define C_CD_FAULT_STOP_I					276
#define C_CD_FAULT_STOP_T					277
#define C_CD_FAULT_STOP_C					278
#define C_CD_FAULT_STOP_P					279
#define C_CD_FAULT_STOP_WATT_HOUR			280
#define C_CD_FAULT_STOP_CMD					281
#define C_CD_FAULT_STOP_END					281 //fault_stop end
#define C_CD_FAULT_PAUSE_CMD				282
#define C_CD_FAULT_ACC_CYCLE_COUNT			283
#define C_CD_FAULT_UPPER_CAPACITANCE		284
#define C_CD_FAULT_LOWER_CAPACITANCE		285
#define C_CD_FAULT_UPPER_WATT_HOUR			286
#define	C_CD_FAULT_LOWER_WATT_HOUR			287
#define C_CD_FAULT_MULTI_CYCLE_COUNT		288
#define C_CD_FAULT_SOFT_END					299
#define C_CD_AUX_START						300 //aux code
#define C_CD_AUX_END_START					300
#define C_CD_AUX_END_UPPER_TEMP				300
#define C_CD_AUX_END_LOWER_TEMP				301
#define C_CD_AUX_END_UPPER_V				302
#define C_CD_AUX_END_LOWER_V				303
#define C_CD_AUX_END_UPPER_V_BRANCH			304
#define C_CD_AUX_END_LOWER_V_BRANCH			305
#define C_CD_AUX_END_UPPER_TEMP_BRANCH		306
#define C_CD_AUX_END_LOWER_TEMP_BRANCH		307
#define C_CD_AUX_END_END					309
#define C_CD_AUX_FAULT_START				310
#define C_CD_AUX_FAULT_UPPER_TEMP			310
#define C_CD_AUX_FAULT_LOWER_TEMP			311
#define C_CD_AUX_FAULT_UPPER_V				312
#define C_CD_AUX_FAULT_LOWER_V				313
#define C_CD_AUX_FAULT_END					319
#define C_CD_AUX_END						319
#define C_CD_CAN_START						320 //can code
#define C_CD_CAN_END_START					320
#define C_CD_CAN_END_UPPER					320
#define C_CD_CAN_END_LOWER					321
#define C_CD_CAN_END_UPPER_V_BRANCH			322
#define C_CD_CAN_END_LOWER_V_BRANCH			323
#define C_CD_CAN_END_UPPER_TEMP_BRANCH		324
#define C_CD_CAN_END_LOWER_TEMP_BRANCH		325
#define C_CD_CAN_END_UPPER_SOC_BRANCH		326
#define C_CD_CAN_END_LOWER_SOC_BRANCH		327
#define C_CD_CAN_END_FAULT_BRANCH			328
#define C_CD_CAN_END_END					329
#define C_CD_CAN_FAULT_START				330
#define C_CD_CAN_FAULT_UPPER				330
#define C_CD_CAN_FAULT_LOWER				331
#define C_CD_CAN_FAULT_END					339
#define C_CD_CAN_END						339

//Time Value
#define TIME_1SEC							1000
#define TIME_2SEC							2000

//internal io addr
#define I_ADDR_IN_1				CYCLER_I_ADDR_IN_1
#define I_ADDR_IN_2				CYCLER_I_ADDR_IN_2
#define I_ADDR_OUT_1			CYCLER_I_ADDR_OUT_1
#define I_ADDR_OUT_2			CYCLER_I_ADDR_OUT_2

//module io addr
#define M_ADDR_IN_1				CYCLER_M_ADDR_IN_1
#define M_ADDR_IN_2				CYCLER_M_ADDR_IN_2
#define M_ADDR_IN_3				CYCLER_M_ADDR_IN_3
#define M_ADDR_IN_4				CYCLER_M_ADDR_IN_4
#define M_ADDR_OUT_1			CYCLER_M_ADDR_OUT_1
#define M_ADDR_OUT_2			CYCLER_M_ADDR_OUT_2

//dio addr
#define D_ADDR_IN_1				CYCLER_D_ADDR_IN_1
#define D_ADDR_OUT_1			CYCLER_D_ADDR_OUT_1

//ch addr
#define CH_ADDR_MUX_1			CYCLER_CH_ADDR_MUX_1
#define CH_ADDR_MUX_2			CYCLER_CH_ADDR_MUX_2
#define CH_ADDR_MUX_3			CYCLER_CH_ADDR_MUX_3
#define CH_ADDR_DAV_SYNC		CYCLER_CH_ADDR_DAV_SYNC
#define CH_ADDR_DAV_DATA_H		CYCLER_CH_ADDR_DAV_DATA_H
#define CH_ADDR_DAV_DATA_L		CYCLER_CH_ADDR_DAV_DATA_L
#define CH_ADDR_DAI_SYNC		CYCLER_CH_ADDR_DAI_SYNC
#define CH_ADDR_DAI_DATA_H		CYCLER_CH_ADDR_DAI_DATA_H
#define CH_ADDR_DAI_DATA_L		CYCLER_CH_ADDR_DAI_DATA_L
#define CH_ADDR_AD_START		CYCLER_CH_ADDR_AD_START
#define CH_ADDR_AD_DATA_H_A1	CYCLER_CH_ADDR_AD_DATA_H_A1
#define CH_ADDR_AD_DATA_L_A1	CYCLER_CH_ADDR_AD_DATA_L_A1
#define CH_ADDR_AD_DATA_H_A2	CYCLER_CH_ADDR_AD_DATA_H_A2
#define CH_ADDR_AD_DATA_L_A2	CYCLER_CH_ADDR_AD_DATA_L_A2
#define CH_ADDR_AD_DATA_H_A3	CYCLER_CH_ADDR_AD_DATA_H_A3
#define CH_ADDR_AD_DATA_L_A3	CYCLER_CH_ADDR_AD_DATA_L_A3
#define CH_ADDR_AD_DATA_H_B1	CYCLER_CH_ADDR_AD_DATA_H_B1
#define CH_ADDR_AD_DATA_L_B1	CYCLER_CH_ADDR_AD_DATA_L_B1
#define CH_ADDR_AD_DATA_H_B2	CYCLER_CH_ADDR_AD_DATA_H_B2
#define CH_ADDR_AD_DATA_L_B2	CYCLER_CH_ADDR_AD_DATA_L_B2
#define CH_ADDR_AD_DATA_H_B3	CYCLER_CH_ADDR_AD_DATA_H_B3
#define CH_ADDR_AD_DATA_L_B3	CYCLER_CH_ADDR_AD_DATA_L_B3
#endif
