//****************************************************************************
// Copyright (C) 2001-2006  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//
// Contributions: Marcel Offermans (marcel.offermans@luminis.nl)
//                Philipp Baer (philipp.baer@informatik.uni-ulm.de)
//                Garth Zeglin (garthz@ri.cmu.edu)
//****************************************************************************

//****************************************************************************
//
// pcan_main.c - the starting point of the driver,
//               init and cleanup and proc interface
//
// $Id: pcan_main.c 360 2006-02-05 10:49:18Z klaus $
//
//****************************************************************************

//****************************************************************************
// INCLUDES
#include <src/pcan_common.h>     // must always be the 1st include
#include <linux/config.h>

#define KBUILD_MODNAME pcan

#include <linux/module.h>

#include <linux/kernel.h>   // DPRINTK()
#include <linux/slab.h>     // kmalloc()
#include <linux/fs.h>       // everything...
#include <linux/errno.h>    // error codes
#include <linux/types.h>    // size_t
#include <linux/proc_fs.h>  // proc
#include <linux/fcntl.h>    // O_ACCMODE
#include <linux/capability.h> // all about restrictions
#include <linux/param.h>    // because of HZ
#include <asm/system.h>     // cli(), *_flags
#include <asm/uaccess.h>    // copy_...
#include <asm/timex.h>      // get_mtime()

#include <pcan.h>
#include <src/pcan_main.h>

#include <src/pcan_isa.h>   // get support for PCAN-ISA and PCAN-104

#include <src/pcan_fops.h>
#include <src/pcan_fifo.h>
// #include <src/pcan_sja1000.h>

//****************************************************************************
// DEFINES
#define DEFAULT_BTR0BTR1    CAN_BAUD_500K  // defaults to 500 kbit/sec
#define DEFAULT_EXTENDED    1              // catch all frames
#define DEFAULT_LISTENONLY  0

//****************************************************************************
// GLOBALS

// filled by module initialisation
char *type[8] = {NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL};
u16  io[8]    = {0, 0, 0, 0, 0, 0, 0, 0};
u8   irq[8]   = {0, 0, 0, 0, 0, 0, 0, 0};

//----------------------------------------------------------------------------
// the global driver object, create it
struct driverobj pcan_drv = {};

//****************************************************************************
// LOCALS

//****************************************************************************
// CODE

//****************************************************************************
// debug utility
void buffer_dump(u8 *pucBuffer, u16 wLineCount)
{
  #ifdef DEBUG
  int i, j;

  for (i = 0; i < wLineCount; i++)
  {
    printk(KERN_DEBUG "%s: %04x ", DEVICE_NAME, i * 16);

    for (j = 0; j < 8; j++)
      printk(" %02x", *pucBuffer++);

    printk(" ");

    for (j = 0; j < 8; j++)
      printk(" %02x", *pucBuffer++);

    printk("\n");
  }
  #endif
}

//----------------------------------------------------------------------------
// request time in msec, may be it becomes more sophisticated in future
u32 get_mtime(void)
{
	#ifdef KERNEL_26
	return (u32)(monotonic_clock() / 1000);
	#else
  return jiffies * (1000 / HZ);
	#endif
}

//----------------------------------------------------------------------------
// is called when 'cat /proc/pcan' invoked
static int pcan_read_procmem(char *page, char **start, off_t offset, int count, int *eof, void *data)
{
  struct pcandev *dev;
  struct list_head *ptr;
  int    len = 0;
  
  DPRINTK(KERN_DEBUG "%s: pcan_read_procmem()\n", DEVICE_NAME);

  len += sprintf(page + len, "\n");
  len += sprintf(page + len, "*--------- PEAK-Systems CAN interfaces (www.peak-system.com) -----------\n");
  len += sprintf(page + len, "*-----------------------  %s  --------------------------\n", pcan_drv.szVersionString);
  len += sprintf(page + len, "*------------------ %d interfaces @ major %03d found ---------------------\n", 
                     pcan_drv.wDeviceCount, pcan_drv.nMajor);
  len += sprintf(page + len, "*n typ ---base--- irq ---read--- ---write-- ---irqs--- ---error-- status\n");
  
  // loop trough my devices
  for (ptr = pcan_drv.devices.next; ptr != &pcan_drv.devices; ptr = ptr->next)
  {
    u32 dwPort = 0;
    u16 wIrq   = 0;
    
    dev = (struct pcandev *)ptr;  
    switch (dev->wType)
    {
      case HW_ISA_SJA:
        dwPort = dev->port.isa.dwPort;
        wIrq   = dev->port.isa.wIrq;
        break;
    }

    len += sprintf(page + len, "%2d %3s 0x%08x %03d 0x%08x 0x%08x 0x%08x 0x%08x 0x%04x\n",
                        dev->nMinor, dev->type, dwPort, wIrq,  
			                           dev->readFifo.dwTotal, dev->writeFifo.dwTotal, dev->dwInterruptCounter, 
						                           dev->dwErrorCounter, dev->wCANStatus);
  }
  
  len += sprintf(page + len, "\n");
  
  *eof = 1;
  return len;
}

//----------------------------------------------------------------------------
// is called when the device is removed 'rmmod pcan'
void cleanup_module(void)
{
  struct pcandev *dev;
  
  DPRINTK(KERN_DEBUG "%s: cleanup_module()\n", DEVICE_NAME);

  switch (pcan_drv.wInitStep)
  {
    case 3: remove_proc_entry(DEVICE_NAME, NULL);
    case 2:
            unregister_chrdev(pcan_drv.nMajor, DEVICE_NAME);
    case 1: 
    case 0: 
            while (!list_empty(&pcan_drv.devices)) // cycle through the list of devices and remove them
            {
              dev = (struct pcandev *)pcan_drv.devices.prev; // empty in reverse order

              dev->cleanup(dev);

              list_del(&dev->list);
	            
		          // free all device allocted memory 
              kfree(dev);
            }
        
	          pcan_drv.wInitStep = 0;
	}
	
  printk(KERN_INFO "%s: removed.\n", DEVICE_NAME);
}

//----------------------------------------------------------------------------
// init some equal parts of dev
void pcan_soft_init(struct pcandev *dev, char *szType, u16 wType)
{
  dev->wType            = wType;
  dev->type             = szType; 
	      
  dev->nOpenPaths       = 0;
  dev->nLastError       = 0;
  dev->dwErrorCounter   = 0;
  dev->dwInterruptCounter = 0;
  dev->wCANStatus       = 0;
  dev->pdwInitTime      = &pcan_drv.dwInitTime;
  dev->bExtended        = 1;   // accept all frames
  dev->wBTR0BTR1        = DEFAULT_BTR0BTR1;
  dev->ucCANMsgType     = DEFAULT_EXTENDED;
  dev->ucListenOnly     = DEFAULT_LISTENONLY;

  // set default access functions
  dev->device_open      = NULL;
  dev->device_release   = NULL;
  dev->device_write     = NULL;

  dev->ucPhysicallyInstalled = 0;  // assume the device is not installed

  atomic_set(&dev->DataSendReady, 1);

  // init fifos
  pcan_fifo_init(&dev->readFifo,   &dev->rMsg[0], &dev->rMsg[READ_MESSAGE_COUNT - 1],  READ_MESSAGE_COUNT,  sizeof(TPCANRdMsg));
  pcan_fifo_init(&dev->writeFifo,  &dev->wMsg[0], &dev->wMsg[WRITE_MESSAGE_COUNT - 1], WRITE_MESSAGE_COUNT, sizeof(TPCANMsg) );
}

//----------------------------------------------------------------------------
// create all declared Peak legacy devices
static int make_legacy_devices(void)
{
	int result = 0;
  int i;

  DPRINTK(KERN_DEBUG "%s: make_legacy_devices()\n", DEVICE_NAME);
	
  for (i = 0; ((i < 8) && (type[i] != NULL)); i++)
  {
		if (!strncmp(type[i], "isa", 4))
			result = pcan_create_isa_devices(type[i], io[i], irq[i]);
    
		if (result)
			break;
  }
 
	return result;
}

#ifdef LINUX_22
//----------------------------------------------------------------------------
// replacement for kernel 2.4.x function
// original from sysdep.h  from the book
// "Linux Device Drivers" by Alessandro Rubini and Jonathan Corbet, published by O'Reilly & Associates.
static struct proc_dir_entry *create_proc_read_entry(const char *name, mode_t mode, 
                                        struct proc_dir_entry *base, read_proc_t *read_proc, void * data)
{
  struct proc_dir_entry *res = create_proc_entry(name, mode, base);
  if (res) 
  {
    res->read_proc=read_proc;
    res->data=data;
  }
  return res;
}
#endif

//----------------------------------------------------------------------------
// is called when the device is installed 'insmod pcan.o' or 'insmod pcan.ko'
int init_module(void)
{
  int result = 0;

  pcan_drv.wInitStep       = 0;
  pcan_drv.dwInitTime      = get_mtime();     // store time for timestamp relation, increments in msec
  pcan_drv.szVersionString = CURRENT_RELEASE; // get the release name global
  pcan_drv.nMajor          = PCAN_MAJOR;
  
  printk(KERN_INFO "%s: %s\n", DEVICE_NAME, pcan_drv.szVersionString);

  INIT_LIST_HEAD(&pcan_drv.devices);
  pcan_drv.wDeviceCount = 0;

  // create isa devices
  if ((result = make_legacy_devices()))
    goto fail;

  // no device found, stop all
  if (!pcan_drv.wDeviceCount)
    goto fail;

  pcan_drv.wInitStep = 1;

  if ((result = register_chrdev(pcan_drv.nMajor, DEVICE_NAME, &pcan_fops)) < 0)
    goto fail;

  if (!pcan_drv.nMajor)
    pcan_drv.nMajor = result;

  pcan_drv.wInitStep = 2;

  // create the proc entry
  if (create_proc_read_entry(DEVICE_NAME, 0, NULL, pcan_read_procmem, NULL) == NULL)
  {
    result = -ENODEV; // maybe wrong if there is no proc filesystem configured
    goto fail;
  }

  pcan_drv.wInitStep = 3;

  printk(KERN_INFO "%s: major %d.\n", DEVICE_NAME, pcan_drv.nMajor);
  return 0; // succeed

  fail:
  cleanup_module();
  return result;
}

