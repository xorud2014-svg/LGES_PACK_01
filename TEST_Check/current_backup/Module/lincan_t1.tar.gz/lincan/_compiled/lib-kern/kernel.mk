LINUX_ARCH=i386
LINUX_LDFLAGS=
LINUX_ARFLAGS=rv
LINUX_CROSS_COMPILE=
LINUX_KERNELRELEASE=2.4.19-rtl3.2-pre2
LINUX_AFLAGS=-D__ASSEMBLY__ -D__KERNEL__ -I/usr/src/linux-2.4.19/include
LINUX_CFLAGS=-D__KERNEL__ -I/usr/src/linux-2.4.19/include -Wall -Wstrict-prototypes -Wno-trigraphs -O2 -fno-strict-aliasing -fno-common -fomit-frame-pointer -pipe -mpreferred-stack-boundary=2 -march=i586 -DMODULE -DMODVERSIONS -include /usr/src/linux-2.4.19/include/linux/modversions.h
LINUX_CC=gcc
LINUX_LD=ld -m elf_i386 -e stext
LINUX_AS=as
LINUX_AR=ar
LINUX_MODULE_EXT=.o
