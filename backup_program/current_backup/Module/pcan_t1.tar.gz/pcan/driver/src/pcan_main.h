#ifndef __PCAN_MAIN_H__
#define __PCAN_MAIN_H__

//****************************************************************************
// Copyright (C) 2001-2006  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//
// Contributions: Marcel Offermans (marcel.offermans@luminis.nl)
//                Philipp Baer (philipp.baer@informatik.uni-ulm.de)
//****************************************************************************

//****************************************************************************
//
// pcan_main.h - global defines to include in all files this module is made of
//
// $Id: pcan_main.h 360 2006-02-05 10:49:18Z klaus $
//
//****************************************************************************

//----------------------------------------------------------------------------
// INCLUDES
#include <src/pcan_common.h>

#include <linux/types.h>
#include <linux/list.h>
#include <linux/wait.h>

#include <linux/spinlock.h>

#include <asm/atomic.h>

#include <pcan.h>

//----------------------------------------------------------------------------
// DEFINES
#define CHANNEL_SINGLE 0                                   // this is a single channel device
#define CHANNEL_MASTER 1                                   // multi channel device, this device is master
#define CHANNEL_SLAVE  2                                   // multi channel device, this is slave

#define READBUFFER_SIZE      80                            // buffers used in read and write call
#define WRITEBUFFER_SIZE     80
#define PCAN_MAJOR            0                            // use dynamic major allocation, else use 91
#define DEVICE_NAME      "pcan"                            // the name of the module and the proc entry
#define READ_MESSAGE_COUNT  500                            // max read message count
#define WRITE_MESSAGE_COUNT  50                            // max write message count

#ifdef DEVFS_SUPPORT
#define PCAN_DEVFS_DIR    "can"                            // name of directory containing symlinks
#endif

// parameter wBTR0BTR1
// bitrate codes of BTR0/BTR1 registers
#define CAN_BAUD_1M     0x0014                             //   1 MBit/s
#define CAN_BAUD_500K   0x001C                             // 500 kBit/s
#define CAN_BAUD_250K   0x011C                             // 250 kBit/s
#define CAN_BAUD_125K   0x031C                             // 125 kBit/s
#define CAN_BAUD_100K   0x432F                             // 100 kBit/s
#define CAN_BAUD_50K    0x472F                             //  50 kBit/s
#define CAN_BAUD_20K    0x532F                             //  20 kBit/s
#define CAN_BAUD_10K    0x672F                             //  10 kBit/s
#define CAN_BAUD_5K     0x7F7F                             //   5 kBit/s

typedef struct
{
  u16        wStepSize;       // size of bytes to step to next entry
  u16        wCopySize;       // size of bytes to copy
  void       *bufferBegin;    // points to first element
  void       *bufferEnd;      // points to the last element
  int        nCount;          // max count of elements in fifo
  int        nStored;         // count of currently received and stored messages
  u32        dwTotal;         // received messages
  void       *r;              // points to the next Msg to read into the read buffer
  void       *w;              // points to the next Msg to write into read buffer
  spinlock_t lock;            // mutual exclusion lock
  unsigned long flags;        // used by spin_lock_irqsave(..);
	u8         need_irqrestore; // restore irs only if this is set
} FIFO_MANAGER;

typedef struct
{
  u32  dwPort;                // the port of the transport layer
  u16  wIrq;                  // the associated irq level
} ISA_PORT;

typedef struct pcandev
{
  struct list_head list;      // link anchor for list of devices
  int  nOpenPaths;            // number of open paths linked to the device
  u16  wInitStep;             // device specific init state
  int  nMinor;                // the associated minor
  char *type;                 // the literal type of the device, info only
  u16  wType;                 // (number type) to distinguish sp and epp

  union
  {
    DONGLE_PORT dng;          // private data of the various ports
    ISA_PORT    isa;
    PCI_PORT    pci;
  } port;

  u8   (*readreg)(struct pcandev *dev, u8 port);           // read a register
  void (*writereg)(struct pcandev *dev, u8 port, u8 data); // write a register
  int  (*cleanup)(struct pcandev *dev);                    // cleanup the interface
  int  (*open)(struct pcandev *dev);                       // called at open of a path
  int  (*release)(struct pcandev *dev);                    // called at release of a path
  int  (*req_irq)(struct pcandev *dev);                    // install the interrupt handler
  void (*free_irq)(struct pcandev *dev);                   // release the interrupt

  int  (*device_open)(struct pcandev *dev, u16 btr0btr1, u8 bExtended, u8 bListenOnly); // open the device itself
  void (*device_release)(struct pcandev *dev);             // release the device itself
  int  (*device_write)(struct pcandev *dev);               // write the device

  wait_queue_head_t read_queue;                            // read process wait queue anchor
  wait_queue_head_t write_queue;                           // write process wait queue anchor

  u8   bExtended;                                          // if 0, no extended frames are accepted
  u32  *pdwInitTime;                                       // time in msec when init was called  
  int  nLastError;                                         // last error written
  u32  dwErrorCounter;                                     // counts all fatal errors
  u32  dwInterruptCounter;                                 // counts all interrupts
  u16  wCANStatus;                                         // status of CAN chip
  u16  wBTR0BTR1;                                          // the persistent storage for BTR0 and BTR1
  u8   ucCANMsgType;                                       // the persistent storage for 11 or 29 bit identifier
  u8   ucListenOnly;                                       // the persistent storage for listen-only mode
  u8   ucPhysicallyInstalled;                              // the device is PhysicallyInstalled
  atomic_t DataSendReady;                                  // !=0 if all data are send

  FIFO_MANAGER readFifo;                                   // manages the read fifo
  FIFO_MANAGER writeFifo;                                  // manages the write fifo
  TPCANRdMsg rMsg[READ_MESSAGE_COUNT];                     // all read messages
  TPCANMsg   wMsg[WRITE_MESSAGE_COUNT];                    // all write messages
} PCANDEV;

typedef struct fileobj
{
  struct pcandev *dev;                                     // pointer to related device
  u8     pcReadBuffer[READBUFFER_SIZE];                    // buffer used in read() call
  u8     *pcReadPointer;                                   // points into current read data rest
  int    nReadRest;                                        // rest of data left to read
  int    nTotalReadCount;                                  // for test only
  u8     pcWriteBuffer[WRITEBUFFER_SIZE];                  // buffer used in write() call
  u8     *pcWritePointer;                                  // work pointer into buffer
  int    nWriteCount;                                      // count of written data bytes
} FILEOBJ;

typedef struct driverobj
{
  int nMajor;                                              // the major number of Pcan interfaces
  u16 wDeviceCount;                                        // count of found devices
  u16 wInitStep;                                           // driver specific init state
  u32 dwInitTime;                                          // time in msec when init was called  
  struct list_head devices;                                // base of list of devices
  u8  *szVersionString;                                    // pointer to the driver version string
} DRIVEROBJ;

//----------------------------------------------------------------------------
// the global driver object
extern struct driverobj pcan_drv;

//----------------------------------------------------------------------------
// exported functions - not to Linux kernel!
u32  get_mtime(void); // request time in msec
void pcan_soft_init(struct pcandev *dev, char *szType, u16 wType);
void buffer_dump(u8 *pucBuffer, u16 wLineCount);

#endif // __PCAN_MAIN_H__

