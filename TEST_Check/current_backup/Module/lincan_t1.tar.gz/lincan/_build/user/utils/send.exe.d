/project/Cycler_KATECH_400V_250A_10A/current/cycler/Module/rt_can/_compiled/bin-utils/send: \
  /usr/lib/crt1.o  \
  /usr/lib/crti.o  \
  /usr/lib/gcc-lib/i386-redhat-linux/2.95.4/crtbegin.o  \
  send.o  \
  /usr/lib/gcc-lib/i386-redhat-linux/2.95.4/libgcc.a  \
  /usr/lib/libc.so  \
  /lib/libc.so.6  \
  /usr/lib/libc_nonshared.a  \
  /usr/lib/gcc-lib/i386-redhat-linux/2.95.4/libgcc.a  \
  /usr/lib/gcc-lib/i386-redhat-linux/2.95.4/crtend.o  \
  /usr/lib/crtn.o  \

