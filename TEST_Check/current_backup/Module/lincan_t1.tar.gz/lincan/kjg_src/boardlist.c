/* boards_list.c
 * Linux CAN-bus device driver.
 * Written for new CAN driver version by Pavel Pisa - OCERA team member
 * email:pisa@cmp.felk.cvut.cz
 * This software is released under the GPL-License.
 * Version lincan-0.3  17 Jun 2004
 */

#include "../include/can.h"
#include "../include/can_sysdep.h"
#include "../include/main.h"

extern int template_register(struct hwspecops_t *hwspecops);
extern int virtual_register(struct hwspecops_t *hwspecops);
extern int oscar_register(struct hwspecops_t *hwspecops);
extern int pcm3680_register(struct hwspecops_t *hwspecops);
extern int pikronisa_register(struct hwspecops_t *hwspecops);
extern int unican_register(struct hwspecops_t *hwspecops);
extern int ipci165_register(struct hwspecops_t *hwspecops);

const struct boardtype_t can_boardtypes[]={
    #ifdef CONFIG_OC_LINCAN_CARD_template
	{"template", template_register, 1},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_virtual
	{"virtual", virtual_register, 0},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_oscar
	{"oscar", oscar_register, 1},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_pcm3680
	{"pcm3680", pcm3680_register, 2},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_pikronisa
	{"pikronisa", pikronisa_register, 1},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_unican
	{"unican", unican_register, 1},
    #endif
    #ifdef CONFIG_OC_LINCAN_CARD_ipci165
	{"ipci165", ipci165_register, 0},
    #endif
	{NULL}
};

const struct boardtype_t* boardtype_find(const char *str)
{
	const struct boardtype_t *brp;

	for(brp=can_boardtypes;brp->boardtype;brp++) {
		if(!strcmp(str,brp->boardtype))
			return brp;
	}

	return NULL;
}
