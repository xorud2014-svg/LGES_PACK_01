#ifndef __MODULECONTROL_DEF_H__
#define __MODULECONTROL_DEF_H__

#include "HW_Addr_Cycler_SK_450V_200A_10A_360KW.h"

//sbc type
#define SBC_HS_6637							1
#define SBC_WEB_6580						2
#define SBC_HS_4020							3
#define SBC_WAFER_E669						4
#define SBC_WAFER_LX800						5
#define SBC_WAFER_MARK533					6
#define SBC_EM104_A5362						7
#define SBC_WAFER_MARK800					8

//test condition define
#define MAX_TEST_STEP         				100 //for general
//#define MAX_TEST_STEP         				210 //for SBL 50A, 400A
//#define MAX_TEST_PATTERN					5 //default
#define MAX_TEST_PATTERN					20 //for LGC 081027 : sbc 128M->256M
//#define MAX_TEST_PATTERN					40 //for SKE 090312 : sbc 128M->256M
#define MAX_PATTERN_DATA					20001
#define MAX_COM_TEST_OBJECT					60
#define MAX_LOC_TEST_OBJECT					200
#define MAX_TEST_GRADE        				10
#define MAX_COM_FAULT_CODE					50
#define MAX_LOC_FAULT_CODE					300
#define MAX_AUX_FAULT_CODE					50
#define MAX_CAN_FAULT_CODE					50

//step type
#define STEP_IDLE							0
#define	STEP_CHARGE							1
#define	STEP_DISCHARGE						2
#define	STEP_REST							3
#define	STEP_OCV							4
#define STEP_Z								5
#define	STEP_END							6
#define STEP_CYCLE							7
#define STEP_LOOP							8
#define STEP_PATTERN						9
#define STEP_LONG_TIME_REST					10

//cali type
#define CALI_IDLE							0
#define CALI_CHARGE							1
#define CALI_DISCHARGE						2

//step mode
#define MODE_IDLE							0
#define	MODE_CCCV							1
#define	MODE_CC								2
#define	MODE_CV								3
#define MODE_DC								4
#define MODE_AC								5
#define MODE_CP								6
#define MODE_CCP							7
#define MODE_CR								8

//value_rate item
#define VALUE_RATE_ITEM_IDLE				0
#define VALUE_RATE_ITEM_AMPARE_HOUR			1
#define VALUE_RATE_ITEM_WATT_HOUR			2

//grade item
#define GRADE_ITEN_IDLE						0
#define GRADE_ITEM_V						1
#define GRADE_ITEM_AMPARE_HOUR				2
#define GRADE_ITEM_Z						3
#define GRADE_ITEM_CAPACITANCE				4

//capacity type
#define CAPACITY_AMPARE_HOURS				0
#define CAPACITY_CAPACITANCE				1

//range define
#define RANGE0								0 //range off
#define RANGE1								1
#define RANGE2								2
#define RANGE3								3
#define RANGE4								4

//operation type
#define OP_INDEPENDENT						0
#define OP_PARALLEL							1

//save flag
#define SAVE_FLAG_MONITORING_DATA			0
#define SAVE_FLAG_SAVING_END				1
#define SAVE_FLAG_SAVING_TIME				2
#define SAVE_FLAG_SAVING_DELTA_V			3
#define SAVE_FLAG_SAVING_DELTA_I			4
#define SAVE_FLAG_SAVING_DELTA_TEMP			5
#define SAVE_FLAG_SAVING_DELTA_P			6
#define SAVE_FLAG_SAVING_ETC				7

//attribute list
#define ATTR_IDLE							0
#define ATTR_CHECK1_START					1	//1step charge
#define ATTR_CHECK1_1						2
#define ATTR_CHECK1_2						3
#define ATTR_CHECK1_3						4
#define ATTR_CHECK1_4						5
#define ATTR_CHECK1_5						6
#define ATTR_CHECK1_6						7
#define ATTR_CHECK1_7						8
#define ATTR_CHECK1_8						9
#define ATTR_CHECK1_9						10
#define ATTR_CHECK1_10						11
#define ATTR_CHECK1_END						12
#define ATTR_DC1_START						21	//1step discharge
#define ATTR_DC1_1							22
#define ATTR_DC1_2							23
#define ATTR_DC1_3							24
#define ATTR_DC1_4							25
#define ATTR_DC1_5							26
#define ATTR_DC1_6							27
#define ATTR_DC1_7							28
#define ATTR_DC1_8							29
#define ATTR_DC1_9							30
#define ATTR_DC1_10							31
#define ATTR_DC1_END						32
#define ATTR_DC2_START						41	//discharge -> rest -> discharge
#define ATTR_DC2_1							42
#define ATTR_DC2_2							43
#define ATTR_DC2_3							44
#define ATTR_DC2_4							45
#define ATTR_DC2_5							46
#define ATTR_DC2_6							47
#define ATTR_DC2_7							48
#define ATTR_DC2_8							49
#define ATTR_DC2_9							50
#define ATTR_DC2_10							51
#define ATTR_DC2_END						52
#define ATTR_DC3_START						61	//chargge -> rest -> charge
#define ATTR_DC3_1							62
#define ATTR_DC3_2							63
#define ATTR_DC3_3							64
#define ATTR_DC3_4							65
#define ATTR_DC3_5							66
#define ATTR_DC3_6							67
#define ATTR_DC3_7							68
#define ATTR_DC3_8							69
#define ATTR_DC3_9							70
#define ATTR_DC3_10							71
#define ATTR_DC3_END						72
#define ATTR_SUB_START						81 //multi step charge/discharge
#define ATTR_SUB_1							82
#define ATTR_SUB_2							83
#define ATTR_SUB_3							84
#define ATTR_SUB_4							85
#define ATTR_SUB_5							86
#define ATTR_SUB_6							87
#define ATTR_SUB_7							88
#define ATTR_SUB_8							89
#define ATTR_SUB_9							90
#define ATTR_SUB_10							91
#define ATTR_SUB_END						92
#define ATTR_TOTAL_CHECK					100 //total check
#define ATTR_CHECK2_START					101 //sbl 1step charge
#define ATTR_CHECK2_1						102
#define ATTR_CHECK2_2						103
#define ATTR_CHECK2_3						104
#define ATTR_CHECK2_4						105
#define ATTR_CHECK2_5						106
#define ATTR_CHECK2_6						107
#define ATTR_CHECK2_7						108
#define ATTR_CHECK2_8						109
#define ATTR_CHECK2_9						110
#define ATTR_CHECK2_10						111
#define ATTR_CHECK2_END						112
#define ATTR_CHECK3_START					121 //sbl 2step ocv
#define ATTR_CHECK3_1						122
#define ATTR_CHECK3_2						123
#define ATTR_CHECK3_3						124
#define ATTR_CHECK3_4						125
#define ATTR_CHECK3_5						126
#define ATTR_CHECK3_6						127
#define ATTR_CHECK3_7						128
#define ATTR_CHECK3_8						129
#define ATTR_CHECK3_9						130
#define ATTR_CHECK3_10						131
#define ATTR_CHECK3_END						132

//common object index
#define IDX_COM_OBJ_TOTAL_STEP				0 //common test conditon
#define IDX_COM_OBJ_ATTRIBUTE_COUNT			1
#define IDX_COM_OBJ_FAULT_HW_UPPER_V		5 //hard fault condition
#define IDX_COM_OBJ_FAULT_HW_LOWER_V		6
#define IDX_COM_OBJ_FAULT_HW_UPPER_I		7
#define IDX_COM_OBJ_FAULT_HW_LOWER_I		8
#define IDX_COM_OBJ_FAULT_HW_UPPER_TEMP		9
#define IDX_COM_OBJ_FAULT_HW_LOWER_TEMP		10
#define IDX_COM_OBJ_FAULT_UPPER_V			15 //soft fault condition
#define IDX_COM_OBJ_FAULT_LOWER_V			16
#define IDX_COM_OBJ_FAULT_UPPER_I			17
#define IDX_COM_OBJ_FAULT_LOWER_I			18
#define IDX_COM_OBJ_FAULT_UPPER_AMPARE_HOUR	19
#define IDX_COM_OBJ_FAULT_LOWER_AMPARE_HOUR	20
#define IDX_COM_OBJ_FAULT_UPPER_TEMP		21
#define IDX_COM_OBJ_FAULT_LOWER_TEMP		22
#define IDX_COM_OBJ_FAULT_MAX_CH			23
//#define IDX_COM_OBJ_FAULT_UPPER_CAPACITANCE	24
//#define IDX_COM_OBJ_FAULT_LOWER_CAPACITANCE	25
#define IDX_COM_OBJ_FAULT_UPPER_WATT_HOUR	24
#define IDX_COM_OBJ_FAULT_LOWER_WATT_HOUR	25
#define IDX_COM_OBJ_FAULT_CHARGE_UPPER_V	26 //sbl common_safety start
#define IDX_COM_OBJ_FAULT_CHARGE_UPPER_AMPARE_HOUR	27
#define IDX_COM_OBJ_FAULT_CHARGE_CHECK_V	28
#define IDX_COM_OBJ_FAULT_CHARGE_CHECK_TIME	29
#define IDX_COM_OBJ_FAULT_CHARGE_END_UPPER_V	30
#define IDX_COM_OBJ_FAULT_CHARGE_LOWER_I	31
#define IDX_COM_OBJ_FAULT_DISCHARGE_LOWER_V	32
#define IDX_COM_OBJ_FAULT_DISCHARGE_RUN_TIME	33
#define IDX_COM_OBJ_FAULT_DISCHARGE_LOWER_AMPARE_HOUR	34
#define IDX_COM_OBJ_FAULT_OVER_CURRENT_LIMIT	35
#define IDX_COM_OBJ_FAULT_COMP_V_T1			36
#define IDX_COM_OBJ_FAULT_COMP_LOWER_V1		37
#define IDX_COM_OBJ_FAULT_COMP_UPPER_V1		38
#define IDX_COM_OBJ_FAULT_COMP_V_T2			39
#define IDX_COM_OBJ_FAULT_COMP_LOWER_V2		40
#define IDX_COM_OBJ_FAULT_COMP_UPPER_V2		41
#define IDX_COM_OBJ_FAULT_COMP_V_T3			42
#define IDX_COM_OBJ_FAULT_COMP_LOWER_V3		43
#define IDX_COM_OBJ_FAULT_COMP_UPPER_V3		44
#define IDX_COM_OBJ_FAULT_COMP_LOWER_CV_TIME	45
#define IDX_COM_OBJ_FAULT_COMP_UPPER_CV_TIME	46
#define IDX_COM_OBJ_FAULT_COMP_I_T1			47
#define IDX_COM_OBJ_FAULT_COMP_LOWER_I1		48
#define IDX_COM_OBJ_FAULT_COMP_UPPER_I1		49 //sbl common_safety end

//local object index
#define IDX_LOC_OBJ_CLIENT_STEP_NO			0 //step condition
#define IDX_LOC_OBJ_STEP_NO					1
#define IDX_LOC_OBJ_TYPE					2
#define IDX_LOC_OBJ_MODE					3
#define IDX_LOC_OBJ_ATTRIBUTE				4
#define IDX_LOC_OBJ_REF_V					5
#define IDX_LOC_OBJ_REF_I					6
#define IDX_LOC_OBJ_REF_P					7
#define IDX_LOC_OBJ_RANGE_V					8
#define IDX_LOC_OBJ_RANGE_I					9
#define IDX_LOC_OBJ_TEST_END				10
#define IDX_LOC_OBJ_TOTAL_SUB_STEP			11
#define IDX_LOC_OBJ_CAPACITANCE_V1			12
#define IDX_LOC_OBJ_CAPACITANCE_V2			13
#define IDX_LOC_OBJ_Z_T1					14
#define IDX_LOC_OBJ_Z_T2					15
#define IDX_LOC_OBJ_LC_T1					16
#define IDX_LOC_OBJ_LC_T2					17
#define IDX_LOC_OBJ_REF_R					18
#define IDX_LOC_OBJ_PATTERN_INDEX			19
#define IDX_LOC_OBJ_REF_V2					20 //for discharge cv ref at pattern

#define IDX_LOC_OBJ_SAVE_DELTA_T			30 //save condition
#define IDX_LOC_OBJ_SAVE_DELTA_V			31
#define IDX_LOC_OBJ_SAVE_DELTA_I			32
#define IDX_LOC_OBJ_SAVE_DELTA_TEMP			33
#define IDX_LOC_OBJ_SAVE_DELTA_P			34

#define IDX_LOC_OBJ_END_CONDITION_START		40 //end condition start
#define IDX_LOC_OBJ_END_SUM_AMPARE_HOUR		40
#define IDX_LOC_OBJ_END_SUM_WATT_HOUR		41

#define IDX_LOC_OBJ_END_V_UPPER				42
#define IDX_LOC_OBJ_END_V_UPPER_BRANCH		43
#define IDX_LOC_OBJ_END_V_LOWER				44
#define IDX_LOC_OBJ_END_V_LOWER_BRANCH		45
#define IDX_LOC_OBJ_END_TIME				46
#define IDX_LOC_OBJ_END_TIME_BRANCH			47
#define IDX_LOC_OBJ_END_CV_TIME				48
#define IDX_LOC_OBJ_END_CV_TIME_BRANCH		49
#define IDX_LOC_OBJ_END_AMPARE_HOUR			50
#define IDX_LOC_OBJ_END_AMPARE_HOUR_BRANCH	51
#define IDX_LOC_OBJ_END_WATT_HOUR			52
#define IDX_LOC_OBJ_END_WATT_HOUR_BRANCH	53
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE	54
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE_BRANCH	55
#define IDX_LOC_OBJ_END_AMPARE_HOUR_RATE_COMPARE	56
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE		57
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE_BRANCH	58
#define IDX_LOC_OBJ_END_WATT_HOUR_RATE_COMPARE	59

#define IDX_LOC_OBJ_END_CYCLE_COUNT			60
#define IDX_LOC_OBJ_END_CYCLE_COUNT_BRANCH	61
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT	62
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT_BRANCH	63
#define IDX_LOC_OBJ_END_MULTI_CYCLE_COUNT_COMPARE	64
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT		65
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT_BRANCH	66
#define IDX_LOC_OBJ_END_ACC_CYCLE_COUNT_COMPARE	67

#define IDX_LOC_OBJ_END_I					68
#define IDX_LOC_OBJ_END_P					69
#define IDX_LOC_OBJ_END_DELTA_V				70
#define IDX_LOC_OBJ_END_DELTA_I				71

#define IDX_LOC_OBJ_END_CAN_V_UPPER			72 //kjg_update 090304 0x1008
#define IDX_LOC_OBJ_END_CAN_V_UPPER_BRANCH	73
#define IDX_LOC_OBJ_END_CAN_V_LOWER			74
#define IDX_LOC_OBJ_END_CAN_V_LOWER_BRANCH	75
#define IDX_LOC_OBJ_END_CAN_TEMP_UPPER		76
#define IDX_LOC_OBJ_END_CAN_TEMP_UPPER_BRANCH	77
#define IDX_LOC_OBJ_END_CAN_TEMP_LOWER		78
#define IDX_LOC_OBJ_END_CAN_TEMP_LOWER_BRANCH	79
#define IDX_LOC_OBJ_END_CAN_SOC_UPPER		80
#define IDX_LOC_OBJ_END_CAN_SOC_UPPER_BRANCH	81
#define IDX_LOC_OBJ_END_CAN_SOC_LOWER		82
#define IDX_LOC_OBJ_END_CAN_SOC_LOWER_BRANCH	83
#define IDX_LOC_OBJ_END_CAN_FAULT			84
#define IDX_LOC_OBJ_END_CAN_FAULT_BRANCH	85

#define IDX_LOC_OBJ_END_AUX_V_UPPER			86
#define IDX_LOC_OBJ_END_AUX_V_UPPER_BRANCH	87
#define IDX_LOC_OBJ_END_AUX_V_LOWER			88
#define IDX_LOC_OBJ_END_AUX_V_LOWER_BRANCH	89
#define IDX_LOC_OBJ_END_AUX_TEMP_UPPER		90
#define IDX_LOC_OBJ_END_AUX_TEMP_UPPER_BRANCH	91
#define IDX_LOC_OBJ_END_AUX_TEMP_LOWER		92
#define IDX_LOC_OBJ_END_AUX_TEMP_LOWER_BRANCH	93

/*kjgw #define IDX_LOC_OBJ_STOP_V_UPPER			51
#define IDX_LOC_OBJ_STOP_V_LOWER			51
#define IDX_LOC_OBJ_STOP_I					52
#define IDX_LOC_OBJ_STOP_T					53
#define IDX_LOC_OBJ_STOP_C					54
#define IDX_LOC_OBJ_STOP_P					55
#define IDX_LOC_OBJ_STOP_WATT_HOUR			56*/
#define IDX_LOC_OBJ_END_CONDITION_END		99 //end condition end 

#define IDX_LOC_OBJ_FAULT_HW_UPPER_V		100 //hard fault condition
#define IDX_LOC_OBJ_FAULT_HW_LOWER_V		101
#define IDX_LOC_OBJ_FAULT_HW_UPPER_I		102
#define IDX_LOC_OBJ_FAULT_HW_LOWER_I		103
#define IDX_LOC_OBJ_FAULT_HW_UPPER_TEMP		104
#define IDX_LOC_OBJ_FAULT_HW_LOWER_TEMP		105
#define IDX_LOC_OBJ_FAULT_UPPER_OCV			110 //soft fault condition
#define IDX_LOC_OBJ_FAULT_LOWER_OCV			111
#define IDX_LOC_OBJ_FAULT_UPPER_V			112
#define IDX_LOC_OBJ_FAULT_LOWER_V			113
#define IDX_LOC_OBJ_FAULT_UPPER_I			114
#define IDX_LOC_OBJ_FAULT_LOWER_I			115
#define IDX_LOC_OBJ_FAULT_UPPER_AMPARE_HOUR	116
#define IDX_LOC_OBJ_FAULT_LOWER_AMPARE_HOUR	117
#define IDX_LOC_OBJ_FAULT_UPPER_WATT_HOUR	118
#define IDX_LOC_OBJ_FAULT_LOWER_WATT_HOUR	119
#define IDX_LOC_OBJ_FAULT_UPPER_Z			120
#define IDX_LOC_OBJ_FAULT_LOWER_Z			121

#define IDX_LOC_OBJ_FAULT_COMP_V_T1			122
#define IDX_LOC_OBJ_FAULT_COMP_V_T2			123
#define IDX_LOC_OBJ_FAULT_COMP_V_T3			124
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V1		125
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V2		126
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_V3		127
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V1		128
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V2		129
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_V3		130
#define IDX_LOC_OBJ_FAULT_COMP_I_T1			131
#define IDX_LOC_OBJ_FAULT_COMP_I_T2			132
#define IDX_LOC_OBJ_FAULT_COMP_I_T3			133
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I1		134
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I2		135
#define IDX_LOC_OBJ_FAULT_COMP_LOWER_I3		136
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I1		137
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I2		138
#define IDX_LOC_OBJ_FAULT_COMP_UPPER_I3		139

#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_V_T	140
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_V		141
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_V_T	142
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_V		143
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_I_T	144
#define IDX_LOC_OBJ_FAULT_UPPER_DELTA_I		145
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_I_T	146
#define IDX_LOC_OBJ_FAULT_LOWER_DELTA_I		147
#define IDX_LOC_OBJ_FAULT_UPPER_TEMP		148
#define IDX_LOC_OBJ_FAULT_LOWER_TEMP		149
#define IDX_LOC_OBJ_FAULT_DELTA_TEMP		150
#define IDX_LOC_OBJ_FAULT_UPPER_CAPACITANCE	151
#define IDX_LOC_OBJ_FAULT_LOWER_CAPACITANCE	152
/*#define IDX_LOC_OBJ_FAULT_ACC_CYCLE			153
#define IDX_LOC_OBJ_FAULT_ACC_CYCLE_ID		154
#define IDX_LOC_OBJ_FAULT_MULTI_CYCLE		155
#define IDX_LOC_OBJ_FAULT_MULTI_CYCLE_ID	156*/

//contact check
#define IDX_LOC_OBJ_FAULT_CHECK_UPPER_V		160
#define IDX_LOC_OBJ_FAULT_CHECK_LOWER_V		161
#define IDX_LOC_OBJ_FAULT_CHECK_UPPER_I		162
#define IDX_LOC_OBJ_FAULT_CHECK_LOWER_I		163

//sbl contact check
#define IDX_LOC_OBJ_FAULT_CHECK_DETECT_V	164
#define IDX_LOC_OBJ_FAULT_CHECK_REVERSE_V	165
#define IDX_LOC_OBJ_FAULT_CHECK_UPPER_OCV	166
#define IDX_LOC_OBJ_FAULT_CHECK_LOWER_OCV	167
#define IDX_LOC_OBJ_FAULT_CHECK_I_JUDGE_RATIO	168
#define IDX_LOC_OBJ_FAULT_CHECK_UPPER_DELTA_V	169
#define IDX_LOC_OBJ_FAULT_CHECK_LOWER_DELTA_V	170

//sbl step ng condition
#define IDX_LOC_OBJ_FAULT_VOLTAGE_DATA_MIN	171
#define IDX_LOC_OBJ_FAULT_VOLTAGE_DATA_MAX	172
#define IDX_LOC_OBJ_FAULT_VOLTAGE_AVG_MIN	173
#define IDX_LOC_OBJ_FAULT_VOLTAGE_AVG_MAX	174
#define IDX_LOC_OBJ_FAULT_AMPARE_HOUR_DATA_MIN	175
#define IDX_LOC_OBJ_FAULT_AMPARE_HOUR_DATA_MAX	176
#define IDX_LOC_OBJ_FAULT_AMPARE_HOUR_AVG_MIN	177
#define IDX_LOC_OBJ_FAULT_AMPARE_HOUR_AVG_MAX	178
#define IDX_LOC_OBJ_FAULT_POWER_DATA_MIN	179
#define IDX_LOC_OBJ_FAULT_POWER_DATA_MAX	180
#define IDX_LOC_OBJ_FAULT_POWER_AVG_MIN		181
#define IDX_LOC_OBJ_FAULT_POWER_AVG_MAX		182

#define IDX_LOC_OBJ_RECODE_DELTA_TIME		190

//module state
#define	M_IDLE								0
#define M_STANDBY							1
#define M_RUN								2
#define M_PAUSE								3
#define M_CALI								4
#define M_FAIL								5

//group state
#define G_IDLE								0
#define G_STANDBY							1
#define G_RUN								2
#define G_PAUSE								3
#define G_CALI								4

//board state
#define B_IDLE								0
#define B_STANDBY							1
#define B_RUN								2
#define B_PAUSE								3
#define B_CALI								4

//channel state
#define	C_IDLE								0
#define	C_STANDBY							1
#define C_RUN								2
#define C_PAUSE								3
#define C_CALI								4
#define C_FAULT								5

//semi switch state
#define SEMI_IDLE							0
#define SEMI_I_P							1
#define SEMI_I_N							2
#define SEMI_I_RANGE1						3
#define SEMI_I_RANGE2						4
#define SEMI_I_RANGE3						5
#define SEMI_I_RANGE4						6
#define SEMI_I_0							3 //kjgw

//module signal
#define M_SIG_EXIT_PHASE					0
#define M_SIG_EXIT_TYPE						1
#define M_SIG_EXIT_GROUP					2
/*kjgw #define M_SIG_POWER_OFF_CLR			1
#define M_SIG_UPS_OFF						2
#define M_SIG_SELFTEST_START				3*/

#define M_SIG_LAMP_RUN						21
#define M_SIG_LAMP_STOP						22
#define M_SIG_CALI_RELAY					23
#define M_SIG_REMOTE_SMPS1					24
#define M_SIG_RUN_LED						25
#define M_SIG_FAN_RELAY						26
#define M_SIG_POWER_OFF						27
#define M_SIG_SMPS_FAULT					28
#define M_SIG_OT_FAULT						29
#define M_SIG_SEND_ERROR_CODE				30
#define M_SIG_TEST_SEND_SAVE_DATA			31
#define M_SIG_CALI_RELAY2					32

#define M_SIG_CALIBRATION					50
#define M_SIG_CALI_VI_SELECT				51
#define M_SIG_CALI_CD_SELECT				52
#define M_SIG_CALI_BD_START					53
#define M_SIG_CALI_CH						54
#define M_SIG_CALI_STEP						55
#define M_SIG_CALI_GROUP					56
#define M_SIG_CALI_BD_COUNT					57
#define M_SIG_CALI_SEQUENCE					58
#define M_SIG_CALI_BD_RUNNING				59
#define M_SIG_CALI_METER_DIV				60

//group signal
#define G_SIG_CMD_RUN						0
#define G_SIG_CMD_STOP						1
#define G_SIG_CMD_PAUSE						2
#define G_SIG_CMD_CONTINUE					3
#define G_SIG_CMD_NEXT_STEP					4
#define G_SIG_CMD_CLEAR						5
#define G_SIG_SAVED_FILE_DELETE_COMPLETE	6
#define G_SIG_DATA_SAVE_COMPLETE			7
#define G_SIG_CONTACT_COMPLETE				8
#define G_SIG_DISCONTACT_COMPLETE			9
#define G_SIG_JIG_FAIL						10
#define G_SIG_NEXT_STEP_EXIST				11
#define G_SIG_EXIT_PHASE					12
#define G_SIG_CMD_RESET						13
#define G_SIG_V_CMD_OUTPUT					14
#define G_SIG_I_CMD_OUTPUT					15
#define G_SIG_NET_CHECK						16

#define G_SIG_DATA_SAVE_FAIL				21
#define G_SIG_ALL_CHANNEL_ERROR				22
#define G_SIG_STEP_ZERO_TIME_RECODE			23

//board signal
#define B_SIG_CMD_RUN						0
#define B_SIG_CMD_STOP						1
#define B_SIG_CMD_PAUSE						2
#define B_SIG_CMD_CONTINUE					3
#define B_SIG_CMD_NEXT_STEP					4
#define B_SIG_CMD_RESET						5
#define B_SIG_RUN							6
#define B_SIG_STOP							7
#define B_SIG_V_RANGE_SELECT				8
#define B_SIG_I_RANGE_SELECT				9
#define B_SIG_V_CMD_OUTPUT					10
#define B_SIG_I_CMD_OUTPUT					11
#define B_SIG_CHECK_PAUSE					12
#define B_SIG_RESET							13

#define B_SIG_RESET_LATCHED					20
#define B_SIG_HW_FAULT_CLEAR				21

//channel signal
#define C_SIG_CMD_RUN						0
#define C_SIG_CMD_STOP						1
#define C_SIG_CMD_PAUSE						2
#define C_SIG_CMD_CONTINUE					3
#define C_SIG_CMD_NEXT_STEP					4
#define C_SIG_CMD_RESET						5
#define C_SIG_CMD_CHECK						6
#define C_SIG_CMD_CALI						7
#define C_SIG_CMD_GOTO_STEP					8
#define C_SIG_MODULE_FAULT					9

//#define C_SIG_CHECK_PAUSE					10
#define C_SIG_AUX_DAV						11
#define C_SIG_AUX_DAI						12
#define C_SIG_TEST_CONDITION_RCV			13
#define C_SIG_RESET							15
#define C_SIG_SAVED_FILE_DELETE				16
#define C_SIG_CHECK_DATA_SAVE				17
#define C_SIG_METER_REPLY					20
#define C_SIG_METER_ERROR					21
#define C_SIG_FAULT_HW_OT					22
#define C_SIG_FAULT_M_PS					23
#define C_SIG_V_CMD_OUTPUT					25
#define C_SIG_I_CMD_OUTPUT					26
#define C_SIG_RUN_RELAY_ON					27
#define C_SIG_RUN_RELAY_OFF					28

#define C_SIG_CALI_NORMAL					30
#define C_SIG_CALI_CHECK					31
#define C_SIG_CALI_POINT					32
#define C_SIG_CALI_PHASE					33
#define C_SIG_CALI_NORMAL_RESULT_SAVED		34
#define C_SIG_CALI_CHECK_RESULT_SAVED		35

#define C_SIG_OUT_SWITCH					40
#define C_SIG_SEMI_SWITCH					41
#define C_SIG_SELECTED_RANGE_I				42
#define C_SIG_C_D_SELECT					43
#define C_SIG_SMPS_FAULT					44
#define C_SIG_FAULT_M_POWER_SWITCH			45
#define C_SIG_FAULT_M_EMG_SWITCH			46
#define C_SIG_FAULT_M_AC_POWER				47
#define C_SIG_FAULT_M_UPS_BATTERY			48
#define C_SIG_USER_CONTROL					49
#define C_SIG_READ_PATTERN_FILE_END			50

//code
#define M_CD_NONE							0
#define M_CD_FAULT_AC_POWER_SHORT			1	
#define M_CD_FAULT_AC_POWER_LONG			2
#define M_CD_FAULT_UPS_BATTERY				3
#define M_CD_FAULT_MAIN_EMG_SWITCH			4
#define M_CD_FAULT_SUB_EMG_SWITCH			5
#define M_CD_FAULT_CONTROL_PS				6
#define M_CD_FAULT_OT						7	
#define M_CD_FAULT_WARNING_POWER_OFF		8
#define M_CD_FAULT_NORMAL_POWER_OFF			9
#define M_CD_FAULT_FORCE_POWER_OFF			10
#define M_CD_FAULT_NORMAL_TERMINAL_QUIT		11
#define M_CD_FAULT_FORCE_TERMINAL_QUIT		12
#define M_CD_FAULT_NORMAL_TERMINAL_HALT		13
#define M_CD_FAULT_FORCE_TERMINAL_HALT		14
#define M_CD_FAULT_CPU_WATCHDOG				15
#define M_CD_FAULT_CALI_METER_COMM_ERROR	16
#define M_CD_FAULT_CALIBRATOR_COMM_ERROR	17
#define M_CD_FAULT_FUSE						18
#define M_CD_FAULT_UPPER_VOLTAGE			19
#define M_CD_FAULT_LOWER_VOLTAGE			20
#define M_CD_FAULT_MAIN_PS					21
#define M_CD_FAULT_CHAMBER					22
#define M_CD_FAULT_CHAMBER_FIRE				23	//khk
//#define M_CD_FAULT_CHAMBER_DOOR_OPEN		24	//khk

#define G_CD_NONE							0
#define G_CD_FAULT_UPPER_VOLTAGE			50
#define G_CD_FAULT_UPPER_CURRENT			51
#define G_CD_FAULT_RUN_TIME_OVER			52
#define G_CD_FAULT_DATASAVE_PROCESS_ERROR	53
#define G_CD_FAULT_ADC						54
#define G_CD_FAULT_OT						55

#define G_CD_FAULT_JIG_ACTIVE_ERROR			56
#define G_CD_FAULT_JIG_TRAY_ERROR			57
#define G_CD_FAULT_JIG_SMOKE_ERROR			58
#define G_CD_FAULT_JIG_TEMP_ERROR			59
#define G_CD_FAULT_JIG_GAS_ERROR			60
#define G_CD_FAULT_JIG_DOOR_ERROR			61
#define G_CD_FAULT_JIG_AIR_PRESS_ERROR		62
#define G_CD_FAULT_JIG_STACKER_ERROR		63

#define G_CD_FAULT_J_MAIN_CYL_UP_TIMEOUT	64
#define G_CD_FAULT_J_MAIN_CYL_DOWN_TIMEOUT	65
#define G_CD_FAULT_J_MAIN_CYL_UP_SENS		66
#define G_CD_FAULT_J_MAIN_CYL_DOWN_SENS		67
#define G_CD_FAULT_J_LATCH_CYL_OPEN_TIMEOUT	68
#define G_CD_FAULT_J_LATCH_CYL_CLOSE_TIMEOUT	69
#define G_CD_FAULT_J_LATCH_CYL_OPEN_SENS	70
#define G_CD_FAULT_J_LATCH_CYL_CLOSE_SENS	71
#define G_CD_FAULT_J_GRIP_CYL_OPEN_TIMEOUT	72
#define G_CD_FAULT_J_GRIP_CYL_CLOSE_TIMEOUT	73
#define G_CD_FAULT_J_GRIP_CYL_OPEN_SENS		74
#define G_CD_FAULT_J_GRIP_CYL_CLOSE_SENS	75
#define G_CD_FAULT_J_TRAY_STATUS_SENS		76
#define G_CD_FAULT_J_TRAY_DIR_SENS			77
#define G_CD_FAULT_J_DOOR_SENS				78
#define G_CD_FAULT_J_STK_SIGNAL_INVALID		79
#define G_CD_FAULT_J_STK_UNLOADING_END		80
#define G_CD_FAULT_J_TRAY_UNLOAD			81

#define B_CD_NONE							0
#define B_CD_FAULT_OT						100
#define B_CD_FAULT_ADC						101

#define C_CD_NONE							0
#define C_CD_COM_START						120 //common code
#define C_CD_COM_FAULT_HW_UPPER_V			120
#define C_CD_COM_FAULT_HW_LOWER_V			121
#define C_CD_COM_FAULT_HW_UPPER_I			122
#define C_CD_COM_FAULT_HW_LOWER_I			123
#define C_CD_COM_FAULT_HW_UPPER_TEMP		124
#define C_CD_COM_FAULT_HW_LOWER_TEMP		125
#define C_CD_COM_FAULT_UPPER_V				126
#define C_CD_COM_FAULT_LOWER_V				127
#define C_CD_COM_FAULT_UPPER_I				128
#define C_CD_COM_FAULT_LOWER_I				129
#define C_CD_COM_FAULT_UPPER_AMPARE_HOUR	130
#define C_CD_COM_FAULT_LOWER_AMPARE_HOUR	131
#define C_CD_COM_FAULT_UPPER_TEMP			132	//kjgw_s
#define C_CD_COM_FAULT_LOWER_TEMP			133
#define C_CD_COM_FAULT_UPPER_CAPACITANCE	134
#define C_CD_COM_FAULT_LOWER_CAPACITANCE	135	//kjgw_e
#define C_CD_COM_FAULT_CHARGE_UPPER_V		136 //for sbl start
#define C_CD_COM_FAULT_CHARGE_UPPER_AMPARE_HOUR	137
#define C_CD_COM_FAULT_CHARGE_END_UPPER_V	138
#define C_CD_COM_FAULT_CHARGE_LOWER_I		139
#define C_CD_COM_FAULT_DISCHARGE_LOWER_V	140
#define C_CD_COM_FAULT_DISCHARGE_RUN_TIME	141
#define C_CD_COM_FAULT_DISCHARGE_LOWER_AMPARE_HOUR	142
#define C_CD_COM_FAULT_OVER_CURRENT_LIMIT	143
#define C_CD_COM_FAULT_COMP_UPPER_V1		144
#define C_CD_COM_FAULT_COMP_LOWER_V1		145
#define C_CD_COM_FAULT_COMP_UPPER_V2		146
#define C_CD_COM_FAULT_COMP_LOWER_V2		147
#define C_CD_COM_FAULT_COMP_UPPER_V3		148
#define C_CD_COM_FAULT_COMP_LOWER_V3		149
#define C_CD_COM_FAULT_COMP_UPPER_I1		150
#define C_CD_COM_FAULT_COMP_LOWER_I1		151
#define C_CD_COM_FAULT_COMP_UPPER_I2		152
#define C_CD_COM_FAULT_COMP_LOWER_I2		153
#define C_CD_COM_FAULT_COMP_UPPER_I3		154
#define C_CD_COM_FAULT_COMP_LOWER_I3		155
#define C_CD_COM_FAULT_COMP_LOWER_CV_TIME	156
#define C_CD_COM_FAULT_COMP_UPPER_CV_TIME	157 //for sbl end
#define C_CD_COM_END						169

#define C_CD_END_START						170 //end code
#define C_CD_END_TIME						170
#define C_CD_END_V_UPPER					171
#define C_CD_END_I							172
#define C_CD_END_AMPARE_HOUR				173
#define C_CD_END_OCV						174
#define C_CD_END_STEP						175
#define C_CD_END_CHECK						176
#define C_CD_END_NEXT_STEP_CMD				177
#define C_CD_END_CYCLE						178
#define C_CD_END_LOOP						179
#define C_CD_END_Z							180
#define C_CD_END_DELTA_V					181
#define C_CD_END_DELTA_I					182
#define C_CD_END_VALUE_RATE_AMPARE_HOUR		183
#define C_CD_END_P							184
#define C_CD_END_WATT_HOUR					185
#define C_CD_END_V_LOWER					186
#define C_CD_END_CV_TIME					187
#define C_CD_END_GOTO_STEP_CMD				188
#define C_CD_END_STOP_CMD					189
#define C_CD_END_VALUE_RATE_WATT_HOUR		190
#define C_CD_END_SUM_AMPARE_HOUR			191
#define C_CD_END_SUM_WATT_HOUR				192
#define C_CD_END_END						209

#define C_CD_SAVE_START						210 //save code
#define C_CD_SAVE_DELTA_T					210
#define C_CD_SAVE_DELTA_V					211
#define C_CD_SAVE_DELTA_I					212
#define C_CD_SAVE_DELTA_TEMP				213
#define C_CD_SAVE_DELTA_P					214
#define C_CD_SAVE_END						229

#define C_CD_FAULT_HARD_START				230	//hard fault code
#define C_CD_FAULT_HW_UPPER_V				230
#define C_CD_FAULT_HW_LOWER_V				231
#define C_CD_FAULT_HW_UPPER_I				232
#define C_CD_FAULT_HW_LOWER_I				233
#define C_CD_FAULT_HW_OT					234
#define C_CD_FAULT_CHANNEL_PS				235
#define C_CD_FAULT_PS_OV					236
#define C_CD_FAULT_PS_OC					237
#define C_CD_FAULT_PS_DCOV					238
#define C_CD_FAULT_IN_FUSE					239
#define C_CD_FAULT_OUT_FUSE					240
#define C_CD_FAULT_HARD_END					249

#define C_CD_FAULT_EXTERNAL_START			250 //external fault code
#define C_CD_FAULT_M_CPU_WATCHDOG			250
#define C_CD_FAULT_M_AC_POWER				251
#define C_CD_FAULT_M_UPS_BATTERY			252
#define C_CD_FAULT_M_EMG_SWITCH				253
#define C_CD_FAULT_M_FORCE_POWER_SWITCH		254
#define C_CD_FAULT_M_FORCE_TERMINAL_HALT	255
#define C_CD_FAULT_M_FORCE_TERMINAL_QUIT	256
#define C_CD_FAULT_G_NETWORK_COMM			257
#define C_CD_FAULT_B_UPPER_TEMP				258
#define C_CD_FAULT_B_ADC					259
#define C_CD_FAULT_CONTROL_PS				260
#define C_CD_FAULT_READ_PATTERN_FILE		261
#define C_CD_FAULT_EXTERNAL_END				279

#define C_CD_FAULT_CHECK_START				280 //check fault code
#define	C_CD_FAULT_CHECK_NG					280
#define C_CD_FAULT_CHECK_UPPER_OCV			281
#define C_CD_FAULT_CHECK_LOWER_OCV			282
#define C_CD_FAULT_CHECK_UPPER_V			283
#define C_CD_FAULT_CHECK_LOWER_V			284
#define C_CD_FAULT_CHECK_UPPER_I			285
#define C_CD_FAULT_CHECK_LOWER_I			286
#define C_CD_FAULT_CHECK_ERROR_NO			287
#define C_CD_FAULT_CHECK_ERROR_YES			288
#define C_CD_FAULT_CHECK_DETECT_V			289	//for sbl start
#define C_CD_FAULT_CHECK_REVERSE_V			290
#define C_CD_FAULT_CHECK_I_JUDGE_RATIO		291
#define C_CD_FAULT_CHECK_UPPER_DELTA_V		292
#define C_CD_FAULT_CHECK_LOWER_DELTA_V		293 //for sbl end
#define C_CD_FAULT_CHECK_END				309

#define C_CD_FAULT_SOFT_START				310 //soft fault code
#define	C_CD_FAULT_UPPER_V					310
#define	C_CD_FAULT_LOWER_V					311
#define C_CD_FAULT_UPPER_DELTA_V			312
#define C_CD_FAULT_LOWER_DELTA_V			313
#define C_CD_FAULT_UPPER_COMP_V1			314
#define C_CD_FAULT_LOWER_COMP_V1			315
#define C_CD_FAULT_UPPER_COMP_V2			316
#define C_CD_FAULT_LOWER_COMP_V2			317
#define C_CD_FAULT_UPPER_COMP_V3			318
#define C_CD_FAULT_LOWER_COMP_V3			319
#define C_CD_FAULT_UPPER_OCV				320
#define C_CD_FAULT_LOWER_OCV				321
#define	C_CD_FAULT_UPPER_I					322
#define C_CD_FAULT_LOWER_I					323
#define C_CD_FAULT_UPPER_DELTA_I			324
#define C_CD_FAULT_LOWER_DELTA_I			325
#define C_CD_FAULT_UPPER_COMP_I1			326
#define C_CD_FAULT_LOWER_COMP_I1			327
#define C_CD_FAULT_UPPER_T					328
#define C_CD_FAULT_LOWER_T					329
#define C_CD_FAULT_UPPER_AMPARE_HOUR		330
#define	C_CD_FAULT_LOWER_AMPARE_HOUR		331
#define C_CD_FAULT_UPPER_DELTA_C			332
#define	C_CD_FAULT_LOWER_DELTA_C			333
#define C_CD_FAULT_UPPER_COMP_C				334
#define	C_CD_FAULT_LOWER_COMP_C				335
#define C_CD_FAULT_UPPER_Z					336
#define C_CD_FAULT_LOWER_Z					337
#define C_CD_FAULT_UPPER_TEMP				338
#define C_CD_FAULT_LOWER_TEMP				339
#define C_CD_FAULT_DELTA_TEMP				340
#define C_CD_FAULT_UPPER_COMP_I2			341
#define C_CD_FAULT_LOWER_COMP_I2			342
#define C_CD_FAULT_UPPER_COMP_I3			343
#define C_CD_FAULT_LOWER_COMP_I3			344
#define C_CD_FAULT_STOP_START				345 //fault_stop start
#define C_CD_FAULT_STOP_V					345
#define C_CD_FAULT_STOP_I					346
#define C_CD_FAULT_STOP_T					347
#define C_CD_FAULT_STOP_C					348
#define C_CD_FAULT_STOP_P					349
#define C_CD_FAULT_STOP_WATT_HOUR			350
#define C_CD_FAULT_STOP_CMD					351
#define C_CD_FAULT_STOP_END					351 //fault_stop end
#define C_CD_FAULT_PAUSE_CMD				352
#define C_CD_FAULT_ACC_CYCLE_COUNT			353
#define C_CD_FAULT_UPPER_CAPACITANCE		354
#define C_CD_FAULT_LOWER_CAPACITANCE		355
#define C_CD_FAULT_UPPER_WATT_HOUR			356
#define	C_CD_FAULT_LOWER_WATT_HOUR			357
#define C_CD_FAULT_MULTI_CYCLE_COUNT		358
#define C_CD_FAULT_RUN_HOLD					359
#define C_CD_FAULT_VOLTAGE_DATA_MIN			360 //for sbl ng condition start
#define C_CD_FAULT_VOLTAGE_DATA_MAX			361
#define C_CD_FAULT_VOLTAGE_AVG_MIN			362
#define C_CD_FAULT_VOLTAGE_AVG_MAX			363
#define C_CD_FAULT_AMPARE_HOUR_DATA_MIN		364
#define C_CD_FAULT_AMPARE_HOUR_DATA_MAX		365
#define C_CD_FAULT_AMPARE_HOUR_AVG_MIN		366
#define C_CD_FAULT_AMPARE_HOUR_AVG_MAX		367
#define C_CD_FAULT_POWER_DATA_MIN			368
#define C_CD_FAULT_POWER_DATA_MAX			369
#define C_CD_FAULT_POWER_AVG_MIN			370
#define C_CD_FAULT_POWER_AVG_MAX			371 //for sbl ng condition end
#define C_CD_FAULT_SOFT_END					379

#define C_CD_AUX_START						380 //aux code
#define C_CD_AUX_END_START					380
#define C_CD_AUX_END_UPPER_TEMP				380
#define C_CD_AUX_END_LOWER_TEMP				381
#define C_CD_AUX_END_UPPER_V				382
#define C_CD_AUX_END_LOWER_V				383
#define C_CD_AUX_END_UPPER_V_BRANCH			384
#define C_CD_AUX_END_LOWER_V_BRANCH			385
#define C_CD_AUX_END_UPPER_TEMP_BRANCH		386
#define C_CD_AUX_END_LOWER_TEMP_BRANCH		387
#define C_CD_AUX_END_END					389
#define C_CD_AUX_FAULT_START				390
#define C_CD_AUX_FAULT_UPPER_TEMP			390
#define C_CD_AUX_FAULT_LOWER_TEMP			391
#define C_CD_AUX_FAULT_UPPER_V				392
#define C_CD_AUX_FAULT_LOWER_V				393
#define C_CD_AUX_FAULT_END					399
#define C_CD_AUX_END						429

#define C_CD_CAN_START						430 //can code
#define C_CD_CAN_END_START					430
#define C_CD_CAN_END_UPPER					430
#define C_CD_CAN_END_LOWER					431
#define C_CD_CAN_END_UPPER_V_BRANCH			432
#define C_CD_CAN_END_LOWER_V_BRANCH			433
#define C_CD_CAN_END_UPPER_TEMP_BRANCH		434
#define C_CD_CAN_END_LOWER_TEMP_BRANCH		435
#define C_CD_CAN_END_UPPER_SOC_BRANCH		436
#define C_CD_CAN_END_LOWER_SOC_BRANCH		437
#define C_CD_CAN_END_FAULT_BRANCH			438
#define C_CD_CAN_END_END					439
#define C_CD_CAN_FAULT_START				440
#define C_CD_CAN_FAULT_UPPER				440
#define C_CD_CAN_FAULT_LOWER				441
#define C_CD_CAN_FAULT_END					449
#define C_CD_CAN_END						449

//Time Value
#define TIME_1SEC							1000
#define TIME_2SEC							2000

//internal io addr
#define I_ADDR_IN_1							HW_I_ADDR_IN_1
#define I_ADDR_IN_2							HW_I_ADDR_IN_2
#define I_ADDR_OUT_1						HW_I_ADDR_OUT_1
#define I_ADDR_OUT_2						HW_I_ADDR_OUT_2

//module io addr
#define M_ADDR_IN_1							HW_M_ADDR_IN_1
#define M_ADDR_IN_2							HW_M_ADDR_IN_2
#define M_ADDR_IN_3							HW_M_ADDR_IN_3
#define M_ADDR_IN_4							HW_M_ADDR_IN_4
#define M_ADDR_OUT_1						HW_M_ADDR_OUT_1
#define M_ADDR_OUT_2						HW_M_ADDR_OUT_2

//dio addr
#define D_ADDR_IN_1							HW_D_ADDR_IN_1
#define D_ADDR_OUT_1						HW_D_ADDR_OUT_1

//ch addr
#define CH_ADDR_MUX_1						HW_CH_ADDR_MUX_1
#define CH_ADDR_MUX_2						HW_CH_ADDR_MUX_2
#define CH_ADDR_MUX_3						HW_CH_ADDR_MUX_3
#define CH_ADDR_DAV_SYNC					HW_CH_ADDR_DAV_SYNC
#define CH_ADDR_DAV_DATA_H					HW_CH_ADDR_DAV_DATA_H
#define CH_ADDR_DAV_DATA_L					HW_CH_ADDR_DAV_DATA_L
#define CH_ADDR_DAI_SYNC					HW_CH_ADDR_DAI_SYNC
#define CH_ADDR_DAI_DATA_H					HW_CH_ADDR_DAI_DATA_H
#define CH_ADDR_DAI_DATA_L					HW_CH_ADDR_DAI_DATA_L
#define CH_ADDR_AD_START					HW_CH_ADDR_AD_START
#define CH_ADDR_AD_DATA_H_A1				HW_CH_ADDR_AD_DATA_H_A1
#define CH_ADDR_AD_DATA_L_A1				HW_CH_ADDR_AD_DATA_L_A1
#define CH_ADDR_AD_DATA_H_A2				HW_CH_ADDR_AD_DATA_H_A2
#define CH_ADDR_AD_DATA_L_A2				HW_CH_ADDR_AD_DATA_L_A2
#define CH_ADDR_AD_DATA_H_A3				HW_CH_ADDR_AD_DATA_H_A3
#define CH_ADDR_AD_DATA_L_A3				HW_CH_ADDR_AD_DATA_L_A3
#define CH_ADDR_AD_DATA_H_B1				HW_CH_ADDR_AD_DATA_H_B1
#define CH_ADDR_AD_DATA_L_B1				HW_CH_ADDR_AD_DATA_L_B1
#define CH_ADDR_AD_DATA_H_B2				HW_CH_ADDR_AD_DATA_H_B2
#define CH_ADDR_AD_DATA_L_B2				HW_CH_ADDR_AD_DATA_L_B2
#define CH_ADDR_AD_DATA_H_B3				HW_CH_ADDR_AD_DATA_H_B3
#define CH_ADDR_AD_DATA_L_B3				HW_CH_ADDR_AD_DATA_L_B3

//common cmd define
#define MAX_CMD_MODE						4

//cmd mode
#define CMD_MODE_USER						0
#define CMD_MODE_STEP						1

//cmd type
#define CMD_TYPE_NONE						0
#define CMD_TYPE_RUN						1
#define CMD_TYPE_STOP						2
#define CMD_TYPE_PAUSE						3
#define CMD_TYPE_NET_PAUSE					4
#define CMD_TYPE_CONTINUE					5
#define CMD_TYPE_NEXT_STEP					6
#define CMD_TYPE_RESET						7
#define CMD_TYPE_CLEAR						8
#define CMD_TYPE_CHECK						9
#define CMD_TYPE_CALI						10
#define CMD_TYPE_CHECK_PAUSE				11

#define BCR_SIZE							64

#endif
