#ifndef __MODULECONTROL_STR_H__
#define __MODULECONTROL_STR_H__

#include "SysDefine.h"
#include "ModuleControl_def.h"

typedef union u_adda_tag {
    short int 			val;
    unsigned char		byte[2];
} U_ADDA;

typedef struct s_ch_misc_tag {
	unsigned char		tmpState;
	unsigned char		tmpPhase;
	unsigned char		semiSwitchState;
	unsigned char		endState;

	int					tmpCode;

	unsigned char		auxDaV;
	unsigned char		auxDaI;
	unsigned char		accumulateGroupCycleID;
	unsigned char		gotoAdvStepNo;

	long				maxV;
	long				minV;
	long				maxI;
	long				minI;
	long				adV[6];
	long				adI[6];
	long				tmpVsens;
	long				tmpIsens;
   	long				tmpWatt;

	long				ccv1;
	long				ccv2;

   	long				sumV[MAX_AD_COUNT];
   	long				sumI[MAX_AD_COUNT];

   	double				sum_charge_AmpareHour;
   	double				seed_charge_AmpareHour;
   	double				sum_discharge_AmpareHour;
   	double				seed_discharge_AmpareHour;
   	double				sum_charge_WattHour;
   	double				seed_charge_WattHour;
   	double				sum_discharge_WattHour;
   	double				seed_discharge_WattHour;

	long				meanSumCount;

	unsigned char		common_codeCount[MAX_COM_FAULT_CODE];
	unsigned char		local_codeCount[MAX_LOC_FAULT_CODE];
	unsigned char		aux_codeCount[MAX_AUX_FAULT_CODE];
	unsigned char		can_codeCount[MAX_CAN_FAULT_CODE];

	long				upper_delta_v_t;
	long				lower_delta_v_t;
	long				upper_delta_i_t;
	long				lower_delta_i_t;
	long				upper_delta_c_t;
	long				lower_delta_c_t;

	long				sensSumV[MAX_FILTER_AD_COUNT];
	long				sensSumI[MAX_FILTER_AD_COUNT];

	long				c_v1;
	long				c_v2;
	unsigned long		c_t1;
	unsigned long		c_t2;
	int					d_count;
	int					d_flag;
	long				d_v[100];
	long				d_t[100];
	long				d_voltage;
	
	short int			sendDataCount;
	short int			pattern_count;
	unsigned long		pattern_time;
   	unsigned long		saveDt;
   	unsigned long		saveDv;
   	unsigned long		saveDi;
   	long				saveDtemp;
	long				actualCapacity;

	unsigned long		advCycleStep;
	unsigned long		advCycle;
	unsigned long		advStepNo;
	unsigned long		currentCycle;
	unsigned long		totalCycle;
	unsigned long		accumulateGroupCycle;

	short int			fbCountV;
	short int			fbCountI;
	long				fbV;
	long				fbI;

	unsigned long		cvTime;

	double				pid_ui1[MAX_TYPE];
	double				pid_error1[MAX_TYPE];

	long				cmd_v;
	long				cmd_i;
	short int			cmd_v_div;
	short int			cmd_i_div;
	long				cmd_p;

	unsigned int		sensCount;
	unsigned int		sensCountFlag;

	long				vs_value;
} S_CH_MISC;

typedef struct s_ch_ccv_tag {
	int					index;
	int					count;
	long				ad_ccv[10];
	long				ad_cci[10];
	long				avg_v;
	long				avg_i;
} S_CH_CCV;

typedef struct s_ch_operation_data_tag {
   	unsigned char		state;
   	unsigned char		phase;
   	unsigned char		stepType;
   	unsigned char		stepMode;

	unsigned char		grade;
	unsigned char		tray_cell_code;
	unsigned char		select;
	unsigned char		ripple_out; //for C_LGC_500V_20A

	//kjgw unsigned char		nonCell;
   	//kjgw unsigned char		preType;

   	unsigned long		totalRunTime;
   	unsigned long		runTime;
   	unsigned long		checkDelayTime;

   	int					stepNo;
	int					code;

   	long				Vsens;
	long				ocv;
	long				meanV;
   	long				Isens;
   	long				meanI;
   	long				watt;
   	long				charge_WattHour;
   	long				discharge_WattHour;
	long				charge_AmpareHour;
	long				discharge_AmpareHour;
   	long				capacitance;
   	long 				z;
	long				temp;

	long				resultIndex;

	unsigned char		rangeV;
	unsigned char		rangeI;
	unsigned char		reservedCmd;	//0:normal, 1:stop, 2:pause
	unsigned char		reserved2;
} S_CH_OP_DATA;

typedef struct s_ch_data_tag {
	S_CH_OP_DATA		op;
	S_CH_OP_DATA		opSave;
	S_CH_CCV			ccv[2];
   	S_CH_MISC			misc;
   	unsigned char		signal[MAX_SIGNAL];
} S_CH_DATA;

typedef struct s_board_source_tag {
	long				sumV[MAX_AD_COUNT];
	long				sensSumV[MAX_FILTER_AD_COUNT];
	long				sourceV;
	long				calSourceV;
	long				sumI[MAX_AD_COUNT];
	long				sensSumI[MAX_FILTER_AD_COUNT];
	long				sourceI;
	long				calSourceI;
} S_BD_SOURCE;

typedef struct s_board_source2_tag {
	long				sumV[MAX_SOURCE_SENS_COUNT];
	long				sourceV;
	long				sumI[MAX_SOURCE_SENS_COUNT];
	long				sourceI;
} S_BD_SOURCE2;

typedef struct s_vi_command_tag {
	long				value;
	unsigned char		range;
	unsigned char		div;
	unsigned char		reserved1[2];
} S_VI_CMD;

typedef struct s_board_misc_tag {
	unsigned char		semiSwitchState;
	unsigned char		rangeV;
	unsigned char		rangeI;
	unsigned char		reserved1;

	long				refV;
	long				refI;
	long				avg_bd_Vsens;
	long				avg_bd_Isens;
	long				avg_bd_watt;

	double				Vsource_AD_a;
	double				Vsource_AD_b;
	double				Vsource_AD_a_N;
	double				Vsource_AD_b_N;
	double				Isource_AD_a;
	double				Isource_AD_b;
	double				Isource_AD_a_N;
	double				Isource_AD_b_N;

	S_BD_SOURCE			source[4];
	S_BD_SOURCE2		source2[4];
	S_VI_CMD			VICmd[MAX_TYPE];
} S_BD_MISC;

typedef struct s_board_data_tag {
	unsigned char		state;
	unsigned char		phase;
	unsigned char		reserved1[2];
	int					code;

   	unsigned char		signal[MAX_SIGNAL];

	unsigned char		outputSwitch;
	unsigned char		C_D_Select;
	unsigned char		readOtFault;
	unsigned char		readHwFault;
	unsigned char		rangeSelectV[MAX_RANGE];
	unsigned char		rangeSelectI[MAX_RANGE];
		
	S_BD_MISC			misc;
} S_BD_DATA;

typedef struct s_ch_grade_tag {
	unsigned char		item;
	unsigned char		totalGrade;
	unsigned char		clientStepNo;
	unsigned char		groupStepNo;
	long				code[MAX_TEST_GRADE];
	long				value1[MAX_TEST_GRADE];
	long				value2[MAX_TEST_GRADE];
} S_CH_GRADE;

typedef struct s_ch_code_tag {
	unsigned char		compCount;
	unsigned char		compType;
	unsigned char		compIndex1;
	unsigned char		compIndex2;
} S_CH_CODE;

typedef struct s_test_cond_reserved_tag {
	unsigned char		reserved_cmd;	//0:normal, 1:stop, 2:pause
	unsigned char		select_run;		//0:normal, 1:select_run
	unsigned char		reserved1[2];
	unsigned long		reserved_stepNo;
	unsigned long		reserved_cycleNo;
	unsigned long		select_stepNo;
	unsigned long		select_cycleNo;
	unsigned long		select_advCycleStep;
} S_TEST_COND_RESERVED;

typedef struct s_test_cond_pattern_tag {
	long				t_val;
	long				cmd_val;
} S_TEST_COND_PATTERN;

typedef struct s_test_condition_tag {
	long				common_object[MAX_COM_TEST_OBJECT];
	long				local_object[MAX_TEST_STEP][MAX_LOC_TEST_OBJECT];
	S_CH_GRADE			grade[MAX_TEST_STEP];
	S_CH_CODE			common_chCode[MAX_COM_FAULT_CODE];
	S_CH_CODE			local_chCode[MAX_TEST_STEP][MAX_LOC_FAULT_CODE];
	S_CH_CODE			aux_chCode[MAX_AUX_FAULT_CODE];
	S_CH_CODE			can_chCode[MAX_CAN_FAULT_CODE];
	S_TEST_COND_RESERVED	reserved;
	S_TEST_COND_PATTERN	pattern[MAX_TEST_PATTERN][MAX_PATTERN_DATA];
} S_TEST_CONDITION;

typedef struct s_group_misc_tag {
	unsigned char		semiSwitchState;
	unsigned char		reserved1[3];

	int					chOffset;

	S_VI_CMD			VICmd[MAX_TYPE];
} S_GROUP_MISC;

typedef struct s_group_data_tag {
	unsigned char		state;
	unsigned char		phase;
	unsigned char		rangeV;
	unsigned char		rangeI;

	unsigned char		workMode;
	unsigned char		stepType;
	unsigned char		stepMode;
	unsigned char		attribute;

	int					code;
	int					stepNo;
	int					advStepNo;
	int					cycleNo;
	int					advCycleNo;
	int					start_stepNo;
	int					client_stepNo;

	unsigned char		signal[MAX_SIGNAL];

	S_GROUP_MISC		misc;
} S_GROUP_DATA;

typedef struct s_module_misc_tag {
	int					mainSlot;
	int					shiftSlot;

	int					processPointer;
	long				timer_1sec;
	int					timer_1sec_count;
	int					bdSensCount;
	int					sourceSensCount;
	int					SubSensV_SourceSensCount;
	int					SubSensV_ChSensCount;

	unsigned char		bdSensCountFlag;
	unsigned char		sourceSensCountFlag;
	unsigned char		SubSensV_SourceSensCountFlag;
	unsigned char		SubSensV_ChSensCountFlag;

	unsigned char		ad_muxVal;
	unsigned char		ref_muxVal;
	unsigned char		ch_muxVal;
	unsigned char		reserved1;
} S_MODULE_MISC;

typedef struct s_module_config_tag {
	int					installedBd;
	int					installedCh;
	int					chPerBd;

	int					chInGroup[MAX_GROUP_PER_MODULE];
	int					bdInGroup[MAX_BD_PER_MODULE];
	int					chInBd[MAX_BD_PER_MODULE];
	int					groupInJig[MAX_GROUP_PER_MODULE];
	int					jigInGroup[MAX_JIG_PER_MODULE][MAX_GROUP_PER_MODULE];
	int					chInTray[MAX_GROUP_PER_MODULE][MAX_TRAY_PER_GROUP];

	long				chCheckDelayTime;

	long				maxV[MAX_RANGE];
	long				minV[MAX_RANGE];
	long				maxI[MAX_RANGE];
	long				minI[MAX_RANGE];

	unsigned char		rangeV;
	unsigned char		rangeI;
	unsigned char		ratioV;
	unsigned char		ratioI;

	unsigned char		capacityType;
	unsigned char		daq_type;
	unsigned char		reserved1[2];

	float				adRatioV[MAX_RANGE];
	float				adRatioI[MAX_RANGE];
	float				daRatioV[MAX_RANGE];
	float				daRatioI[MAX_RANGE];
	float				shuntR[MAX_RANGE];

	long				scan_period;

	short int			installedTemp;
	short int			installedAuxV;
	short int			installedCAN;
	short int			reserved2;
} S_MODULE_CONFIG;

typedef struct s_module_data_tag {
    unsigned char		state;
    unsigned char		phase;
	unsigned char		reserved1[2];
    int					code;

	unsigned char		signal[MAX_SIGNAL];
	
	S_MODULE_MISC		misc;
	S_MODULE_CONFIG		config;

	long				runningTime[6][10];
	long				real_time[7];
} S_MODULE_DATA;

typedef struct s_aux_set_data_tag {
	unsigned char		chNo;			//1base : machine channel number
	unsigned char		reserved1[3];
	short int			auxChNo;		//1base : aux channel number
	short int			auxType;		//0:temperature, 1:v
	char				name[MAX_AUX_NAME_SIZE];
	long				fault_upper;
	long				fault_lower;
	long				end_upper;
	long				end_lower;
	long				reserved2[2];
} S_AUX_SET_DATA;

typedef struct s_ch_attribute_tag {
	unsigned char		chNo_master;	//1base
	unsigned char		chNo_slave[3];	//1base
	unsigned char		opType;			//0:independent, 1:parallel
	unsigned char		reserved1[3];
} S_CH_ATTRIBUTE;

typedef struct s_can_receive_common_data_tag {
	unsigned char		can_baudrate;	//0:125k...
	unsigned char		extended_id;	//0:unused, 1:used
	unsigned char		reserved1[2];

	long				controller_canID;
	long				mask[2];
	long				filter[6];

	float				cell_cv_value;
	long				reserved2[2];
} S_CAN_RECEIVE_COMMON_DATA;

typedef struct s_can_receive_normal_data_tag {
	unsigned char		canType;		//0:unused, 1:master, 2:slave
	unsigned char		byte_order;		//0:intel, 1:motolora
	unsigned char		data_type;	//0:unsigned, 1:signed, 2:float, 3:string
	unsigned char		data_attribute; //cell_cv_flag;

	float				factor;
	short int			startBit;
	short int			bitCount;

	long				canID;			//hex value
	char				name[MAX_CAN_NAME_SIZE];
	float				fault_upper;
	float				fault_lower;
	float				end_upper;
	float				end_lower;

	unsigned char		user_control;
	unsigned char		tmp_user_control;
	unsigned char		reserved1[2];

	float				offset; //kjg081112 0x1006
	float				reserved2;
} S_CAN_RECEIVE_NORMAL_DATA;

typedef struct s_can_receive_set_data_tag {
	S_CAN_RECEIVE_COMMON_DATA	commonData[MAX_CH_PER_MODULE][MAX_CAN_TYPE];
	S_CAN_RECEIVE_NORMAL_DATA	normalData[MAX_CH_PER_MODULE][MAX_CAN_DATA];
} S_CAN_RECEIVE_SET_DATA;

typedef struct s_can_transmit_common_data_tag {
	unsigned char		can_baudrate;	//0:125k...
	unsigned char		extended_id;	//0:unused, 1:used
	unsigned char		reserved1[2];

	long				controller_canID;
	float				inverter_capacitor_v;
	float				mcu_temp;
} S_CAN_TRANSMIT_COMMON_DATA;

typedef struct s_can_transmit_normal_data_tag {
	unsigned char		canType;		//0:unused, 1:master, 2:slave
	unsigned char		byte_order;		//0:intel, 1:motolora
	unsigned char		data_type;	//0:unsigned, 1:signed, 2:float, 3:string
	unsigned char		data_attribute;	//0bit(0:none 1:inverter_capacitor_v)
										//1bit(0:none 1:mcu_temp)

	float				factor;
	float				default_value;
	short int			startBit;
	short int			bitCount;

	long				canID;			//hex value
	long				send_period;
	char				name[MAX_CAN_NAME_SIZE];

	unsigned char		user_control;		//only sbc used
	unsigned char		tmp_user_control;	//only sbc used
	unsigned char		reserved1[2];

	float				offset; //kjg081112 0x1006
	float				reserved2;
} S_CAN_TRANSMIT_NORMAL_DATA;

typedef struct s_can_transmit_set_data_tag {
	S_CAN_TRANSMIT_COMMON_DATA	commonData[MAX_CH_PER_MODULE][MAX_CAN_TYPE];
	S_CAN_TRANSMIT_NORMAL_DATA	normalData[MAX_CH_PER_MODULE][MAX_CAN_DATA];
} S_CAN_TRANSMIT_SET_DATA;

typedef union u_can_data_tag {
	unsigned long		ul_val[2];
	long				l_val[2];
	float				f_val[2];
	unsigned char		uc_val[8];
	char				c_val[8];
} U_CAN_DATA;

#endif
