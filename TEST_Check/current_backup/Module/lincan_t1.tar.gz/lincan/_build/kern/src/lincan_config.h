/* Automatically generated from */
/* config file: /project/Cycler_KATECH_400V_250A_10A/current/cycler/Module/rt_can/config.omk-default */
#ifndef _LOCAL_CONFIG_H
#define _LOCAL_CONFIG_H
#define CONFIG_OC_LINCAN 1
#define CONFIG_OC_LINCAN_DETAILED_ERRORS 1
#define CONFIG_OC_LINCAN_CARD_pcm3680 1
#define CONFIG_OC_LINCAN_CARD_virtual 1
#define CONFIG_OC_LINCAN_CARD_template 1
#endif /*_LOCAL_CONFIG_H*/
