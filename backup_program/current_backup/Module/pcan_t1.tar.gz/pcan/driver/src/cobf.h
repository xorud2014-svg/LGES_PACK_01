//****************************************************************************
// Copyright (C) 2001-2006  PEAK System-Technik GmbH
//
// linux@peak-system.com
// www.peak-system.com
//
// This part of software is proprietary. It is *not* allowed to
// distribute it. No warranty at all is given.
//
// Maintainer(s): Klaus Hitschler (klaus.hitschler@gmx.de)
//****************************************************************************

//****************************************************************************
//
// cobf.h - obfuscation header
//
// $Id: cobf.h 361 2006-02-25 13:50:48Z klaus $
//
//****************************************************************************

/* COBF by BB -- obfuscated at Sat Feb 25 14:47:09 2006
*/
#define pcan_l86 typedef
#define pcan_l143 union
#define pcan_c u8
#define pcan_g uc
#define pcan_l45 u32
#define pcan_l38 dw
#define pcan_l43 u16
#define pcan_l91 w
#define pcan_m struct
#define pcan_l100 u64
#define pcan_l27 static
#define pcan_l72 void
#define pcan_p pcandev
#define pcan_b dev
#define pcan_i t
#define pcan_u port
#define pcan_w usb
#define pcan_l64 pvXptr
#define pcan_o DPRINTK
#define pcan_r KERN_DEBUG
#define pcan_l DEVICE_NAME
#define pcan_l123 inline
#define pcan_l56 register
#define pcan_l82 llx
#define pcan_n return
#define pcan_l148 ucStep
#define pcan_f if
#define pcan_l171 get_mtime
#define pcan_l193 pdwInitTime
#define pcan_e int
#define pcan_l109 sizeof
#define pcan_l108 purb_t
#define pcan_l106 purb
#define pcan_l175 context
#define pcan_l53 status
#define pcan_l166 atomic_sub
#define pcan_l93 active_urbs
#define pcan_l95 atomic_set
#define pcan_l63 param_xmit_finished
#define pcan_y pt
#define pcan_l133 ucPhysicallyInstalled
#define pcan_l147 ENODEV
#define pcan_l154 param_urb
#define pcan_l139 FILL_BULK_URB
#define pcan_l88 usb_dev
#define pcan_l168 usb_sndbulkpipe
#define pcan_l134 Endpoint
#define pcan_l26 ucNumber
#define pcan_l155 timeout
#define pcan_l132 HZ
#define pcan_l145 __usb_submit_urb
#define pcan_l58 KERN_ERR
#define pcan_l46 goto
#define pcan_l31 fail
#define pcan_l28 else
#define pcan_l130 atomic_add
#define pcan_l48 while
#define pcan_l127 atomic_read
#define pcan_l125 schedule
#define pcan_l187 USB_PORT
#define pcan_l159 mdelay
#define pcan_l176 usb_rcvbulkpipe
#define pcan_l92 printk
#define pcan_l146 for
#define pcan_l153 ucDeviceNr
#define pcan_l128 dwSerialNumber
#define pcan_l104 ucRevision
#define pcan_l161 EINVAL
#define pcan_l103 ucMsgLen
#define pcan_l111 dataPacketCounter
#define pcan_j localID
#define pcan_l122 TPCANRdMsg
#define pcan_l34 Msg
#define pcan_l99 LEN
#define pcan_l54 MSGTYPE
#define pcan_l116 MSGTYPE_RTR
#define pcan_l165 MSGTYPE_STANDARD
#define pcan_l141 MSGTYPE_EXTENDED
#define pcan_l129 ID
#define pcan_l135 dwTime
#define pcan_l65 DATA
#define pcan_l173 bExtended
#define pcan_l167 pcan_fifo_put
#define pcan_l185 readFifo
#define pcan_l164 MSGTYPE_STATUS
#define pcan_l160 switch
#define pcan_l49 case
#define pcan_l60 wCANStatus
#define pcan_l179 CAN_ERR_QOVERRUN
#define pcan_l85 dwErrorCounter
#define pcan_l169 CAN_ERR_BUSOFF
#define pcan_l191 CAN_ERR_BUSHEAVY
#define pcan_l184 CAN_ERR_BUSLIGHT
#define pcan_l52 break
#define pcan_l182 CAN_ERR_QXMTFULL
#define pcan_l178 default
#define pcan_l126 buffer_dump
#define pcan_l183 EFAULT
#define pcan_l170 wake_up_interruptible
#define pcan_l163 read_queue
#define pcan_l102 nMsgCounter
#define pcan_l162 TPCANMsg
#define pcan_l188 pcan_fifo_get
#define pcan_l117 writeFifo
#define pcan_l186 ENODATA
#define pcan_l174 nStored
#define pcan_l157 continue
#define pcan_l190 dwTelegramCount
