/* close.c
 * Linux CAN-bus device driver.
 * Written by Arnaud Westenberg email:arnaud@wanadoo.nl
 * Rewritten for new CAN queues by Pavel Pisa - OCERA team member
 * email:pisa@cmp.felk.cvut.cz
 * This software is released under the GPL-License.
 * Version lincan-0.3  17 Jun 2004
 */

#include "../include/can.h"
#include "../include/can_sysdep.h"
#include "../include/main.h"
#include "../include/close.h"
#include "../include/setup.h"
#include "../include/fasync.h"

#define __NO_VERSION__
#include <linux/module.h>

int can_close(struct inode *inode, struct file *file)
{
	struct canuser_t *canuser = (struct canuser_t*)(file->private_data);
	struct canque_ends_t *qends;
	struct msgobj_t *obj;
	can_spin_irqflags_t iflags;
	
	if(!canuser || (canuser->magic != CAN_USER_MAGIC)){
		CANMSG("can_close: bad canuser magic\n");
		return -ENODEV;
	}
	
	obj = canuser->msgobj;
	qends = canuser->qends;
	
    #ifdef CAN_ENABLE_KERN_FASYNC

	can_fasync(-1, file, 0);

    #endif /*CAN_ENABLE_KERN_FASYNC*/

	can_spin_lock_irqsave(&canuser_manipulation_lock, iflags);
	list_del(&canuser->peers);
	can_spin_unlock_irqrestore(&canuser_manipulation_lock, iflags);
	canuser->qends = NULL;
	canqueue_ends_dispose_kern(qends, file->f_flags & O_SYNC);

	kfree(canuser);

	can_spin_lock_irqsave(&canuser_manipulation_lock, iflags);
	if(atomic_dec_and_test(&obj->obj_used)){
		can_msgobj_clear_fl(obj,OPENED);
	};
	can_spin_unlock_irqrestore(&canuser_manipulation_lock, iflags);
	
    #if (LINUX_VERSION_CODE < KERNEL_VERSION(2,5,50))
	MOD_DEC_USE_COUNT;
    #endif
	return 0;
}
