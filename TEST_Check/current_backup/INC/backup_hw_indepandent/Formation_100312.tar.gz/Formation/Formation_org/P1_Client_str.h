#ifndef __P1_CLIENT_STR_H__
#define __P1_CLIENT_STR_H__

#include "SysDefine.h"
#include "P1_Client_def.h"

typedef struct s_p1_array1_tag {
	short int			bd;
	short int			ch;
} S_P1_ARRAY1;

typedef struct s_p1_config_data_tag {
	unsigned char		vAutoCal;		//voltage auto cali. flag-default:1
	unsigned char		iAutoCal;		//current auto cali. flag-default:0
	short int			huttingCount;	//count of hutting check-default:3
	long				vHuttingLevel;	//voltage hutting level(mV)-default:150
	long				iHuttingLevel;	//current hutting level(mA)-default:180
	long				stableTime;		//stabilization time(sec)-default:10
	long				dVstableTime;	//stable time for deltaV(sec)-default:60
	long				vRefNGLevel;	//V Ref IC fail level(digit)-default:300
	long				iRefNGLevel;	//I Ref IC fail level(digit)-default:800
	long				reserved1[32];
	char				reserved2[512];
} S_P1_CONFIG_DATA;

typedef struct s_p1_config_tag {
	S_P1_ARRAY1			ChArray1[MAX_CH_PER_MODULE];
	int					ChArray2[MAX_CH_PER_MODULE];
	int					ChArray3[MAX_CH_PER_MODULE];

    char				ipAddr[16];

	int					sendPort;
	int					receivePort;
	int					networkPort; //common port

    int     			send_socket;
    int     			receive_socket;
    int     			network_socket; //common socket

	int					replyTimeout;
	int					retryCount;
	int					pingTimeout;
	int					netTimeout;
	
	unsigned char		CmdSendLog;
	unsigned char		CmdRcvLog;
	unsigned char		CmdSendLog_Hex;
	unsigned char		CmdRcvLog_Hex;
	
	unsigned char		CommCheckLog;
	unsigned char		workMode;
	short int			groupNo;
	short int			groupId;
	short int			monitoringInterval;
	short int			sensorDataInterval;
	short int			reserved1;

	unsigned char		autoProcess;
	unsigned char		trayCodeReadType;
	unsigned char		useTempLimitFlag;
	unsigned char		useGasLimitFlag;
	long				maxTempLimit;
	long				maxGasLimit;

	unsigned int		state_change;
} S_P1_CONFIG;

typedef struct s_p1_group_state_tag {
	unsigned short		groupState;
	unsigned short		code;
	unsigned short		sensorState[8];
} S_P1_GROUP_STATE;

typedef struct s_p1_misc_tag {
	unsigned long		timer;
	unsigned long		network_timer;
	unsigned long		cmd_serial;
	unsigned long		sended_monitor_data_time;
	unsigned long		sended_sensor_data_time;
	unsigned short		stepCount;
	unsigned short		gradeCount;
	unsigned short		convert_step1;
	unsigned short		convert_step2;

	S_P1_GROUP_STATE	group_state;
	S_P1_GROUP_STATE	tmp_group_state;
/*kjgw	unsigned char		tmpGroupState;
	unsigned char		tmpCode;
	unsigned char		tmpJigState;
	unsigned char		tmpTrayState;
	unsigned char		tmpDoorState;
	unsigned char		reserved1[3];*/

	char				test_serial_no[32];

	int					CO_No;
	int					psSignal;
	int					chPerGroup;
	int					processPointer;
} S_P1_MISC;

typedef struct s_p1_test_config_tag {
	long				maxRefV;
	long				minRefV;
	long				maxRefI;
	long				minRefI;
	long				failDeltaV;
	long				failDeltaI;
	long				check_lowerI;
	long				check_lowerOCV;
} S_P1_TEST_CONFIG;

typedef struct s_p1_rcv_packet_tag {
	int					usedBufSize;

	int					rcvCount;
	int					rcvStartPoint[MAX_P1_PACKET_COUNT];
	int					rcvSize[MAX_P1_PACKET_COUNT];
	char				rcvPacketBuf[MAX_P1_PACKET_LENGTH];

	int					parseCount;
	int					parseStartPoint[MAX_P1_PACKET_COUNT];
} S_P1_RCV_PACKET;

typedef struct s_p1_rcv_command_tag {
	int					cmdBufSize;
	char				cmd[MAX_P1_PACKET_LENGTH];
	char				cmdBuf[MAX_P1_PACKET_LENGTH];
	char				tmpBuf[MAX_P1_PACKET_LENGTH];
	int					cmdFail;
	int					cmdSize;

	int					rcvCmdIndex;
	char				rcvCmd[MAX_P1_PACKET_LENGTH];
	unsigned char		rcvCmdCompleteFlag;
	unsigned char		rcvCmdRestFlag;
	unsigned char		reserved1[2];
} S_P1_RCV_COMMAND;

typedef struct s_p1_retry_data_tag {
	int					seqno;
	int					replyCmd;
	int					count;
	int					size;
	char				buf[MAX_P1_PACKET_LENGTH];
} S_P1_RETRY_DATA;

typedef struct s_p1_reply_tag {
	int					timer_run;
	unsigned long		timer;
	S_P1_RETRY_DATA		retry;
} S_P1_REPLY;

typedef struct s_p1_cmd_header_tag {
	unsigned int		packet_id;
	unsigned short		group_id;
	unsigned short		ch;
	unsigned int		cmd_id;
	unsigned int		cmd_size;

	/*unsigned long		cmd_serial;
	char				cmd_reply; kjgw*/
} S_P1_CMD_HEADER;

typedef struct s_p1_test_header_tag {
	char				testSerial[24];
	char				resultFileName[256];
	unsigned char		totalStep;
	unsigned char		totalGrade;
	unsigned char		reserved1[2];
} S_P1_TEST_HEADER;

typedef struct s_p1_test_precheck_tag {
	long				upperOCV;
	long				lowerOCV;
	long				refV;
	long				refI;
	unsigned long		endTime;
	long				deltaV;
	long				maxFault;
	unsigned char		compFlag;
	unsigned char		autoProcessingYN;
	unsigned char		reserved1[2];
} S_P1_TEST_PRECHECK;

typedef struct s_p1_test_step_header_tag {
	unsigned char		stepNo;
	unsigned char		type;
	unsigned char		mode;
	unsigned char		gradeFlag;
	long				reserved1;
} S_P1_TEST_STEP_HEADER;

typedef struct s_p1_test_step_ocv_tag {
	long				upperV;
	long				lowerV;
} S_P1_TEST_STEP_OCV;

typedef struct s_p1_test_step_charge_tag {
	long				refV;
	long				refI;
	unsigned long		endTime;
	long				endV;
	long				endI;
	long				endCapacity;
	long				endDV;
	long				endDI;

	unsigned char		useActualCapacity;
	unsigned char		reserved1;
	unsigned short int	socRate;

	long				upperV;
	long				lowerV;
	long				upperI;
	long				lowerI;
	long				upperCapacity;
	long				lowerCapacity;

	unsigned long		compTimeV[P1_COMP_POINT];
	long				compLowerV[P1_COMP_POINT];
	long				compUpperV[P1_COMP_POINT];
	unsigned long		compTimeI[P1_COMP_POINT];
	long				compLowerI[P1_COMP_POINT];
	long				compUpperI[P1_COMP_POINT];

	unsigned long		deltaTimeV;
	long				deltaV;
	unsigned long		deltaTimeI;
	long				deltaI;
	long				tmv;
	unsigned long		rTime;
	unsigned long		restTime;
} S_P1_TEST_STEP_CHARGE;

typedef struct s_p1_test_step_discharge_tag {
	long				refV;
	long				refI;
	unsigned long		endTime;
	long				endV;
	long				endI;
	long				endCapacity;
	long				endDV;
	long				endDI;

	unsigned char		useActualCapacity;
	unsigned char		reserved1;
	unsigned short int	socRate;

	long				upperV;
	long				lowerV;
	long				upperI;
	long				lowerI;
	long				upperCapacity;
	long				lowerCapacity;

	unsigned long		compTimeV[P1_COMP_POINT];
	long				compLowerV[P1_COMP_POINT];
	long				compUpperV[P1_COMP_POINT];
	unsigned long		compTimeI[P1_COMP_POINT];
	long				compLowerI[P1_COMP_POINT];
	long				compUpperI[P1_COMP_POINT];

	unsigned long		deltaTimeV;
	long				deltaV;
	unsigned long		deltaTimeI;
	long				deltaI;
	long				tmv;
	unsigned long		rTime;
	unsigned long		restTime;
} S_P1_TEST_STEP_DISCHARGE;

typedef struct s_p1_test_step_z_tag {
	long				refV;
	long				refI;
	unsigned long		endTime;
	long				startVref;
	long				startIref;
	unsigned long		startTime;
	long				upperV;
	long				lowerV;
	long				upperI;
	long				lowerI;
	long				upperZ;
	long				lowerZ;
	unsigned long		restTime;
} S_P1_TEST_STEP_Z;

typedef struct s_p1_test_step_rest_tag {
	unsigned long		endTime;
	long				upperV;
	long				lowerV;
	long				jigUp;
} S_P1_TEST_STEP_REST;

typedef struct s_p1_test_step_end_tag {
} S_P1_TEST_STEP_END;

typedef struct s_p1_test_grade_header_tag {
	unsigned char		stepNo;		//zero base
	unsigned char		totalGrade;	//one base
	short int			item;
} S_P1_TEST_GRADE_HEADER;

typedef struct s_p1_test_grade_tag {
	unsigned char		code;
	unsigned char		reserved1;
	short int			reserved2;
	long				value1;
	long				value2;
} S_P1_TEST_GRADE;

typedef struct s_p1_test_condition_tag {
	S_P1_TEST_HEADER	header;
	S_P1_TEST_PRECHECK	precheck;
	S_P1_TEST_STEP_HEADER	stepHeader[MAX_P1_STEP];
	S_P1_TEST_STEP_OCV	ocv[MAX_P1_STEP];
	S_P1_TEST_STEP_CHARGE	charge[MAX_P1_STEP];
	S_P1_TEST_STEP_DISCHARGE	discharge[MAX_P1_STEP];
	S_P1_TEST_STEP_Z	z[MAX_P1_STEP];
	S_P1_TEST_STEP_REST	rest[MAX_P1_STEP];
	S_P1_TEST_STEP_END	end;
	S_P1_TEST_GRADE_HEADER	gradeHeader[MAX_P1_STEP];
	S_P1_TEST_GRADE		grade[MAX_P1_STEP][MAX_P1_GRADE];
} S_P1_TEST_CONDITION;

typedef struct s_p1_rcv_cmd_test_header_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_HEADER	testHeader;
} S_P1_RCV_CMD_TEST_HEADER;

typedef struct s_p1_rcv_cmd_test_precheck_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_PRECHECK	precheck;
} S_P1_RCV_CMD_TEST_PRECHECK;

typedef struct s_p1_rcv_cmd_test_step_header_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
} S_P1_RCV_CMD_TEST_STEP_HEADER;

typedef struct s_p1_rcv_cmd_test_step_ocv_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_OCV	ocv;
} S_P1_RCV_CMD_TEST_STEP_OCV;

typedef struct s_p1_rcv_cmd_test_step_charge_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_CHARGE	charge;
} S_P1_RCV_CMD_TEST_STEP_CHARGE;

typedef struct s_p1_rcv_cmd_test_step_discharge_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_DISCHARGE	discharge;
} S_P1_RCV_CMD_TEST_STEP_DISCHARGE;

typedef struct s_p1_rcv_cmd_test_step_rest_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_REST	rest;
} S_P1_RCV_CMD_TEST_STEP_REST;

typedef struct s_p1_rcv_cmd_test_step_z_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_Z	z;
} S_P1_RCV_CMD_TEST_STEP_Z;

typedef struct s_p1_rcv_cmd_test_step_end_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_STEP_HEADER	stepHeader;
	S_P1_TEST_STEP_END	end;
} S_P1_RCV_CMD_TEST_STEP_END;

typedef struct s_p1_rcv_cmd_test_grade_header_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_GRADE_HEADER	gradeHeader;
} S_P1_RCV_CMD_TEST_GRADE_HEADER;

typedef struct s_p1_rcv_cmd_test_info_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_TEST_INFO_REQUEST;

typedef struct s_p1_tray_data_tag {
	unsigned char		code[MAX_CH_PER_MODULE];
	unsigned char		reserved1[MAX_CH_PER_MODULE];
} S_P1_TRAY_DATA;

typedef struct s_p1_rcv_cmd_tray_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TRAY_DATA		tray_data;
} S_P1_RCV_CMD_TRAY_DATA;

typedef struct s_p1_cali_set_tag {
	unsigned char		range;
	unsigned char		caliPointNum;
	unsigned char		reserved1[2];
	long				caliPoint[MAX_CALI_POINT];
} S_P1_CALI_SET_POINT;

typedef struct s_p1_cali_point_tag {
	unsigned char		range;
	unsigned char		caliPointNum;
	unsigned char		caliCheckPointNum;
	unsigned char		reserved1;
	long				caliPoint[MAX_CALI_POINT];
	long				caliCheckPoint[MAX_CALI_CHECK_POINT];
} S_P1_CALI_POINT;

typedef struct s_p1_rcv_cmd_version_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_VERSION_REQUEST;

typedef struct s_p1_rcv_cmd_line_mode_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_LINE_MODE_REQUEST;

typedef struct s_p1_rcv_cmd_set_auto_report_tag {
	S_P1_CMD_HEADER		header;
	unsigned int		interval;
	int					reserved1;
} S_P1_RCV_CMD_SET_AUTO_REPORT;

typedef struct s_p1_rcv_cmd_check_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CHECK;

typedef struct s_p1_rcv_cmd_run_tag {
	S_P1_CMD_HEADER		header;
	char				test_serial_no[32];
	long				reserved1;
} S_P1_RCV_CMD_RUN;

typedef struct s_p1_rcv_cmd_stop_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_STOP;

typedef struct s_p1_rcv_cmd_pause_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_PAUSE;

typedef struct s_p1_rcv_cmd_continue_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CONTINUE;

typedef struct s_p1_rcv_cmd_next_step_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_NEXT_STEP;

typedef struct s_p1_rcv_cmd_clear_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CLEAR;

typedef struct s_p1_rcv_cmd_reset_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_RESET;

typedef struct s_p1_rcv_cmd_response_tag {
	S_P1_CMD_HEADER		header;
	int					sent_cmd_id;
	int					code;
} S_P1_RCV_CMD_RESPONSE;

typedef struct s_p1_rcv_cmd_cali_meter_connect_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CALI_METER_CONNECT;

typedef struct s_p1_rcv_cmd_cali_set_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_SET_POINT	set_point[MAX_TYPE][MAX_RANGE];
} S_P1_RCV_CMD_CALI_SET_POINT;

typedef struct s_p1_rcv_cmd_cali_voltage_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_POINT		cali_point;
} S_P1_RCV_CMD_CALI_VOLTAGE;

typedef struct s_p1_rcv_cmd_cali_current_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_POINT		cali_point;
} S_P1_RCV_CMD_CALI_CURRENT;

typedef struct s_p1_rcv_cmd_cali_update_tag {
	S_P1_CMD_HEADER		header;
	long				ch;
} S_P1_RCV_CMD_CALI_UPDATE;

typedef struct s_p1_rcv_cmd_set_group_tag {
	S_P1_CMD_HEADER		header;
	unsigned char		netConnectApproval;
	unsigned char		nvRamFlag;
	unsigned char		useTemp;
	unsigned char		useGas;
	long				maxTemp;
	long				maxGas;
	unsigned int		autoReportInterval;
	unsigned char		trayReadType;
	unsigned char		reserved1;
	short int			reserved2;
	long				vHighLimit; //kjgw
	long				iHighLimit; //kjgw
	long				reserved3[8];
} S_P1_RCV_CMD_SET_GROUP;

typedef struct s_p1_digital_in_tag {
	unsigned char		data[8];
} S_P1_DIGITAL_IN;

typedef struct s_p1_digital_out_tag {
	unsigned char		data[8];
} S_P1_DIGITAL_OUT;

typedef struct s_p1_ref_data_tag {
	long				CaliData;
	char				CaliTime[32]; // 2006/02/17/14:38:00
	long				CurrData;
	char				CurrTime[32]; // 2006/02/17/14:38:00
	long				MinData; //after power on
	char				MinTime[32]; // 2006/02/17/14:38:00
	long				MaxData; //after power on
	char				MaxTime[32]; // 2006/02/17/14:38:00
} S_P1_REF_DATA;

typedef struct s_p1_ref_da_data_tag {
	S_P1_REF_DATA		vPlus;
	S_P1_REF_DATA		vZero;
	S_P1_REF_DATA		vMinus;
	S_P1_REF_DATA		iPlus;
	S_P1_REF_DATA		iZero;
	S_P1_REF_DATA		iMinus;
} S_P1_REF_AD_DATA;

typedef struct s_p1_ref_ic_data_tag {
	S_P1_REF_AD_DATA	data[8];
	long				reserved1[4];
} S_P1_REF_IC_DATA;

typedef struct s_p1_host_time_tag {
	unsigned short		year;
	unsigned short		month;
	unsigned short		day;
	unsigned short		hour;
	unsigned short		minute;
	unsigned short		second;
} S_P1_HOST_TIME;

typedef struct s_p1_sensor_set_tag {
	unsigned char		useSensorFlag[MAX_P1_SENSOR_CH];
	long				maxLimit;
	unsigned char		limitFlag;
	unsigned char		reserved1;
	unsigned short		reserved2;
} S_P1_SENSOR_SET;

typedef struct s_p1_sensor_limit_tag {
	unsigned short int	warning1;
	unsigned short int	warning2;
	S_P1_SENSOR_SET		sensorSet1;
	S_P1_SENSOR_SET		sensorSet2;
	long				reserved1;
} S_P1_SENSOR_LIMIT;

typedef struct s_p1_rcv_cmd_set_sensor_limit_tag {
	S_P1_CMD_HEADER		header;
	S_P1_SENSOR_LIMIT	sensor_limit;
} S_P1_RCV_CMD_SET_SENSOR_LIMIT;

typedef struct s_p1_rcv_cmd_config_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CONFIG_REQUEST;

typedef struct s_p1_rcv_cmd_set_config_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CONFIG_DATA	configData;
} S_P1_RCV_CMD_SET_CONFIG;

typedef struct s_p1_rcv_cmd_comm_check_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_COMM_CHECK;

typedef struct s_p1_rcv_cmd_comm_check_reply_tag {
	S_P1_CMD_HEADER		header;
	char				result[4];
	char				sended_cmd[4];
} S_P1_RCV_CMD_COMM_CHECK_REPLY;

typedef struct s_p1_send_cmd_version_data_tag {
	S_P1_CMD_HEADER		header;
	int					moduleNo;
	int					versionNo;
	int					controllerType;
	
	unsigned short		installedBd;
	unsigned short		chPerBd;
	int					groupNo;
	int					totalChNum;
	unsigned short		trayType;
	unsigned short		totalTrayNum;
	unsigned short		chInTray[MAX_TRAY_PER_GROUP];
} S_P1_SEND_CMD_VERSION_DATA;

typedef struct s_p1_send_cmd_line_mode_data_tag {
	S_P1_CMD_HEADER		header;
	int					onlineMode;
	int					controlMode;
	int					reserved1;
} S_P1_SEND_CMD_LINE_MODE_DATA;

typedef struct s_p1_send_cmd_test_info_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_HEADER	testHeader;
} S_P1_SEND_CMD_TEST_INFO_DATA;

typedef struct s_p1_send_cmd_response_tag {
	S_P1_CMD_HEADER		header;
	int					received_cmd_id;
	int					code;
} S_P1_SEND_CMD_RESPONSE;

typedef struct s_p1_send_cmd_trouble_code_tag {
	S_P1_CMD_HEADER		header;
	int					code;
	int					chNo;
} S_P1_SEND_CMD_TROUBLE_CODE;

typedef struct s_p1_sensor_data_tag {
	long				value;
	long				reserved1;
} S_P1_SENSOR_DATA;

typedef struct s_p1_send_cmd_sensor_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_SENSOR_DATA	sensorData1[MAX_P1_SENSOR_CH];
	S_P1_SENSOR_DATA	sensorData2[MAX_P1_SENSOR_CH];
} S_P1_SEND_CMD_SENSOR_DATA;

typedef struct s_p1_send_cmd_tag_data_tag {
	S_P1_CMD_HEADER		header;
	char				tag[64];
	char				reserved1[64];
} S_P1_SEND_CMD_TAG_DATA;

typedef struct s_p1_test_result_tag {
	unsigned short		stepNo;
	unsigned short		reserved1;
	long				data1[64];
	long				data2[64];
} S_P1_TEST_RESULT;

typedef struct s_p1_ch_data_tag {
	unsigned short		ch;
	unsigned short		state;
	unsigned char		grade;
	unsigned char		code;
	unsigned short		stepNo;
	unsigned long		runTime;
	unsigned long		totalRunTime;
	long				Vsens;
	long				Isens;
	long				watt;
	long				wattHour;
	long				capacity;
	long				z;
} S_P1_CH_DATA;

typedef struct s_p1_ch_sub_data_tag {
	unsigned long		time;
	long				data1;
	long				data2;
} S_P1_CH_SUB_DATA;

typedef struct s_p1_send_cmd_ch_sub_data_tag {
	S_P1_CMD_HEADER		header;
	int					chIndex; //zero base index
	S_P1_CH_SUB_DATA	data[20];
} S_P1_SEND_CMD_CH_SUB_DATA;

typedef struct s_p1_send_cmd_group_state_tag {
	S_P1_CMD_HEADER		header;
	S_P1_GROUP_STATE	state;
} S_P1_SEND_CMD_GROUP_STATE;

typedef struct s_p1_send_cmd_check_data_tag {
	S_P1_CMD_HEADER		header;
	unsigned short		errorChNo;
	unsigned short		normalChNo;
} S_P1_SEND_CMD_CHECK_DATA;

typedef struct s_p1_send_cmd_user_cmd_tag {
	S_P1_CMD_HEADER		header;
	int					data1;
	int					data2;
	unsigned char		reserved1[8];
} S_P1_SEND_CMD_USER_CMD;

typedef struct s_p1_send_cmd_meter_connect_reply_tag {
	S_P1_CMD_HEADER		header;
} S_P1_SEND_CMD_METER_CONNECT_REPLY;

typedef struct s_p1_cali_check_data_tag {
	unsigned char		range;
	unsigned char		caliPointNum;
	unsigned char		caliCheckPointNum;
	unsigned char		ch;
	long				caliPointAD[MAX_CALI_POINT];
	long				caliPointDVM[MAX_CALI_POINT];
	long				caliCheckPointAD[MAX_CALI_POINT];
	long				caliCheckPointDVM[MAX_CALI_POINT];
} S_P1_CALI_CHECK_DATA;

typedef struct s_p1_send_cmd_cali_check_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_CHECK_DATA	caliCheckData;
} S_P1_SEND_CMD_CALI_CHECK_DATA;

typedef struct s_p1_send_cmd_config_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CONFIG_DATA	configData;
} S_P1_SEND_CMD_CONFIG_DATA;

typedef struct s_p1_send_cmd_comm_check_reply_tag {
	S_P1_CMD_HEADER		header;
	char				object_id[4];
	char				result[4];
	char				sended_cmd[4];
} S_P1_SEND_CMD_COMM_CHECK_REPLY;

typedef struct s_p1_send_cmd_comm_check_tag {
	S_P1_CMD_HEADER		header;
} S_P1_SEND_CMD_COMM_CHECK;

typedef struct s_p1_cali_data_tag {
	char				version_name[P1_CALI_VER_NAME_SIZE];
	char				main_bd_serial[P1_MAIN_BD_SERIAL_SIZE];
	char				cali_date[P1_CALI_DATE_SIZE];

	int					DA_Cali_PointNum[MAX_TYPE];
	float				DA_Cali_Cmd[MAX_TYPE][2];
	float				DA_A[MAX_TYPE];
	float				DA_B[MAX_TYPE];

	float				AD_A[MAX_CH_PER_BD][MAX_TYPE];
	float				AD_B[MAX_CH_PER_BD][MAX_TYPE];
	float				DA_AUX_A[MAX_CH_PER_BD][MAX_TYPE];
	float				DA_AUX_B[MAX_CH_PER_BD][MAX_TYPE];
	
	long				ref_AD[MAX_TYPE][3];
	long				ref_AD2_V[2];
} S_P1_CALI_DATA;

#endif
