#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/io.h>

#define NONE	0
#define OUTPUT	1
#define INPUT	2
#define AD		3
#define ADJ		4
#define DACHECK	5
#define MAX_AD_COUNT	10

short REFIC_P5V[MAX_AD_COUNT];
short REFIC_G0V[MAX_AD_COUNT];
short REFIC_N5V[MAX_AD_COUNT];
short REFIC_P5I[MAX_AD_COUNT];
short REFIC_G0I[MAX_AD_COUNT];
short REFIC_N5I[MAX_AD_COUNT];
short REFIC[MAX_AD_COUNT];

union tmpData {
	char	data[2];
	short int	val;
};

union ADData {
	unsigned char	data[2];
	short int	val;
};

int main(void)
{
	unsigned char	wr_data[10], rd_data[10]; 
	int				tx_ch, tx_addr, val1, val2;
	float			f_val1, f_val2;

    int 	i,j;
    int		retval, addr, val, type, mode, phase1;
	int		o_addr, i_addr, count;
	short int	tmpVal;
    char	tmp[10];
	unsigned char	o_val, i_val; 
	unsigned char muxVal2;
    unsigned char	adVal, adVal2;
    struct	timeval tv;
    fd_set	rfds;

	unsigned char kjg_t2[10];
	int kjg_t1[2];

	phase1 = type = o_addr = i_addr = count = 0;
	o_val = muxVal2 = 0;
	mode = NONE;

    if(iopl(3)) exit(1);
	

	while(1) {
		tmp[0] = 0;
		if(mode == NONE) {
			printf("scan1>> ");
			scanf("%s", tmp);
		}

		if(strcmp(tmp, "f_wr") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d %x %x", &tx_ch, &val1, &val2);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x11;
				wr_data[2] = (unsigned char)val1;
				wr_data[3] = (unsigned char)val2;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");
		} else if(strcmp(tmp, "f_rd") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x12;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");
		//} else if(strcmp(tmp, "t_ad") == 0) {
		} else if(strcmp(tmp, "df") == 0) {
			scanf("%d", &val);
			outb(0x00, 0x75F);
			outb((unsigned char)0, 0x750);
			outb((unsigned char)0x12 + val, 0x751);
			outb((unsigned char)0, 0x752);
			outb((unsigned char)0, 0x753);
			outb((unsigned char)0, 0x754);
			outb((unsigned char)0, 0x755);
			outb((unsigned char)0, 0x756);
			outb((unsigned char)0, 0x757);
			outb((unsigned char)0, 0x758);
			outb((unsigned char)0, 0x759);

			usleep(100);
			outb(0x00, 0x75E);
			kjg_t2[0] = inb(0x750); kjg_t2[1] = inb(0x751);
			kjg_t2[2] = inb(0x752); kjg_t2[3] = inb(0x753);
			kjg_t2[4] = inb(0x754); kjg_t2[5] = inb(0x755);
			kjg_t2[6] = inb(0x756); kjg_t2[7] = inb(0x757);
			kjg_t2[8] = inb(0x758); kjg_t2[9] = inb(0x759);
			printf(
				"rx data %02x %02x, %02x %02x %02x %02x, %02x %02x %02x %02x\n",
				kjg_t2[0], kjg_t2[1], kjg_t2[2], kjg_t2[3], kjg_t2[4],
				kjg_t2[5], kjg_t2[6], kjg_t2[7], kjg_t2[8], kjg_t2[9]);
			kjg_t1[0] = (int)kjg_t2[2];
			kjg_t1[0] |= ((int)kjg_t2[3] << 8);
			kjg_t1[0] |= ((int)kjg_t2[4] << 16);
			kjg_t1[0] |= ((int)kjg_t2[5] << 24);
			kjg_t1[1] = (int)kjg_t2[6];
			kjg_t1[1] |= ((int)kjg_t2[7] << 8);
			kjg_t1[1] |= ((int)kjg_t2[8] << 16);
			kjg_t1[1] |= ((int)kjg_t2[9] << 24);
			printf("rx val %d, %d\n", kjg_t1[0], kjg_t1[1]);
		} else if(strcmp(tmp, "f_da1") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d %f %f", &tx_ch, &f_val1, &f_val2);
			val1 = (int)(f_val1 * 1000000.0);
			val2 = (int)(f_val2 * 1000000.0);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x21;
				memcpy((char *)&wr_data[2], (char *)&val1, 4);
				memcpy((char *)&wr_data[6], (char *)&val2, 4);
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");
		} else if(strcmp(tmp, "f_da2") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d %f %f", &tx_ch, &f_val1, &f_val2);
			val1 = (int)(f_val1 * 1000000.0);
			val2 = (int)(f_val2 * 1000000.0);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x22;
				memcpy((char *)&wr_data[2], (char *)&val1, 4);
				memcpy((char *)&wr_data[6], (char *)&val2, 4);
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");
		} else if(strcmp(tmp, "f_ad_ref1") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x31;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");

			memcpy((char *)&val1, (char *)&rd_data[2], 4);
			memcpy((char *)&val2, (char *)&rd_data[6], 4);
			printf("val1:%f, val2:%f\n", val1/1000.0, val2/1000.0);
		} else if(strcmp(tmp, "f_ad_ref2") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x32;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");

			memcpy((char *)&val1, (char *)&rd_data[2], 4);
			memcpy((char *)&val2, (char *)&rd_data[6], 4);
			printf("val1:%f, val2:%f\n", val1/1000.0, val2/1000.0);
		} else if(strcmp(tmp, "f_ad1") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x33;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");

			memcpy((char *)&val1, (char *)&rd_data[2], 4);
			memcpy((char *)&val2, (char *)&rd_data[6], 4);
			printf("val1:%f, val2:%f\n", val1/1000.0, val2/1000.0);
		} else if(strcmp(tmp, "f_ad2") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x34;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");

			memcpy((char *)&val1, (char *)&rd_data[2], 4);
			memcpy((char *)&val2, (char *)&rd_data[6], 4);
			printf("val1:%f, val2:%f\n", val1/1000.0, val2/1000.0);
		} else if(strcmp(tmp, "f_ad3") == 0) {
			memset((char *)&wr_data[0], 0, 10);
			scanf("%d", &tx_ch);

			for(j=0; j < 2; j++) {
				outb((unsigned char)(tx_ch-1), 0x75F);
				wr_data[0] = 0x00;
				wr_data[1] = 0x35;
				tx_addr = 0x750;
				for(i=0; i < 10; i++) {
					outb(wr_data[i], tx_addr + i);
				}
				usleep(100);
			}

			outb((unsigned char)(tx_ch-1), 0x75E);
			printf("rd_data ");
			for(i=0; i < 10; i++) {
				rd_data[i] = inb(tx_addr + i);
				printf("%02x ", rd_data[i]);
			}
			printf("\n");

			memcpy((char *)&val1, (char *)&rd_data[2], 4);
			memcpy((char *)&val2, (char *)&rd_data[6], 4);
			printf("val1:%f, val2:%f\n", val1/1000.0, val2/1000.0);
		}

		if(strcmp(tmp, "write") == 0) {
			scanf("%x %x", &addr, &val);
			printf("write %x %x\n", addr, val);
			o_addr = addr;
			o_val = (unsigned char)val;
			mode = OUTPUT;
		} else if(strcmp(tmp, "wr") == 0) {
			scanf("%x %x", &addr, &val);
			printf("wr %x %x\n", addr, val);
			mode = NONE;
			o_addr = addr;
			o_val = (unsigned char)val;
			outb(o_val,o_addr);
		} else if(strcmp(tmp, "read") == 0) {
			scanf("%x", &addr);
			printf("read 0x%04X\n", addr);
			i_addr = addr;
			mode = INPUT;
		} else if(strcmp(tmp, "get") == 0) {
			scanf("%x", &addr);
			printf("get %x\n", addr);
			mode = NONE;
			i_addr = addr;
			i_val = inb(i_addr);
			printf("get data %x %x\n", i_addr, i_val);
		} else if(strcmp(tmp, "quit") == 0) exit(0);

		FD_ZERO(&rfds);
		tv.tv_sec = 0;
		tv.tv_usec = 100000;

		retval = select(FD_SETSIZE, &rfds, NULL, NULL, &tv);
		if(retval != 0) continue;

		switch(mode) {
			case OUTPUT:
				outb(o_val, o_addr);
				break;
			case INPUT:
				i_val = inb(i_addr);
				printf("%02X",i_val);
				break;
			case AD:
				switch(phase1) {
					case 0:
						if(type == 0) {
							outb(0x00, 0x650);	//AD_START
						} else {
							outb(0x01, 0x650);	//AD_START
						}
						phase1 = 1;
						break;
					case 1:
						for(i=0; i < 3; i++) {
							j = 0x650 + 2 * i;
							adVal = 0;
							adVal = inb(j);	//AD_HADDR
							adVal2 = inb(j+1);//AD_LADDR
							tmpVal = 0;
							tmpVal = adVal;
							tmpVal = tmpVal << 8;
							tmpVal |= adVal2;
							if(type == 0) {
								printf("adv %d %f\n", tmpVal,
									(float)tmpVal/32768.0*10000.0);
								} else {
								printf("adi %d %f\n", tmpVal,
									(float)tmpVal/32768.0*190618.0);
							}
						}
						mode = NONE;
						phase1 = 0;
						break;
					default: break;
				}
				break;
			case ADJ:
				outb(o_addr, 0x529);
				outb(o_val, 0x52a);
				break;
			case DACHECK:
				outb(o_addr, 0x529);
				outb(count, 0x52a);
				count++;
				if(count >= 0xff) count = 0x00;
				break;
			default: break;
		}
	}
    exit(0);
}

