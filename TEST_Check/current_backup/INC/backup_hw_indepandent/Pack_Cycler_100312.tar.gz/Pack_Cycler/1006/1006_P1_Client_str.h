#ifndef __P1_CLIENT_STR_H__
#define __P1_CLIENT_STR_H__

#include "SysDefine.h"
#include "P1_Client_def.h"

typedef struct s_p1_config_tag {
	short int			groupId;
	short int			groupNo;

   	char				ipAddr[16];

	int					sendPort;
	int					receivePort;
	int					networkPort; //common port
	int					protocol_version;

	int					retryCount;
	long				replyTimeout;
	long				netTimeout;
	long				pingTimeout;
	
	unsigned char		CmdSendLog;
	unsigned char		CmdRcvLog;
	unsigned char		CmdSendLog_Hex;
	unsigned char		CmdRcvLog_Hex;
	
	unsigned char		CommCheckLog;
	unsigned char		state_change;
	unsigned char		reserved1[2];

	long				send_monitor_data_interval;
	long				send_save_data_interval;
} S_P1_CONFIG;

typedef struct s_p1_rcv_packet_tag {
	int					usedBufSize;

	int					rcvCount;
	int					rcvStartPoint[MAX_P1_PACKET_COUNT];
	int					rcvSize[MAX_P1_PACKET_COUNT];
	char				rcvPacketBuf[MAX_P1_PACKET_LENGTH];

	int					parseCount;
	int					parseStartPoint[MAX_P1_PACKET_COUNT];
} S_P1_RCV_PACKET;

typedef struct s_p1_rcv_command_tag {
	int					cmdBufSize;
	char				cmd[MAX_P1_PACKET_LENGTH];
	char				cmdBuf[MAX_P1_PACKET_LENGTH];
	char				tmpBuf[MAX_P1_PACKET_LENGTH];
	int					cmdFail;
	int					cmdSize;

	int					rcvCmdIndex;
	char				rcvCmd[MAX_P1_PACKET_LENGTH];
	unsigned char		rcvCmdCompleteFlag;
	unsigned char		rcvCmdRestFlag;
	unsigned char		reserved1[2];
} S_P1_RCV_COMMAND;

typedef struct s_p1_retry_data_tag {
	int					seqno;
	int					replyCmd;
	int					count;
	int					size;
	char				buf[MAX_P1_PACKET_LENGTH];
} S_P1_RETRY_DATA;

typedef struct s_p1_reply_tag {
	int					timer_run;
	unsigned long		timer;
	S_P1_RETRY_DATA		retry;
} S_P1_REPLY;

typedef struct s_p1_cmd_header_tag {
	unsigned long		cmd_id;
	unsigned long		cmd_serial;
	unsigned short		reserved1;
	unsigned short		reserved2;
	unsigned long		chFlag[2];
	unsigned long		body_size;
} S_P1_CMD_HEADER;

typedef struct s_p1_test_cond_header_tag {
	unsigned char		totalStep;
	unsigned char		reserved1[3];
	long				reserved2[2];
} S_P1_TEST_COND_HEADER;

typedef struct s_p1_test_cond_safety_tag {
	long				faultLowerV;
	long				faultUpperV;
	long				faultLowerI;
	long				faultUpperI;
	long				faultLower_AmpareHour;
	long				faultUpper_AmpareHour;
	/*kjgw long				faultLower_Capacitance;
	long				faultUpper_Capacitance;*/
	long				faultLowerTemp; //kjgw_s don't use 080804
	long				faultUpperTemp;	//kjgw_e
	long				reserved1[4];
} S_P1_TEST_COND_SAFETY;

typedef struct s_p1_test_step_header_tag {
	int					type;

	unsigned char		stepNo;
	unsigned char		mode;
	unsigned char		testEnd;
	unsigned char		subStep;

	unsigned char		useSocFlag;
	unsigned char		userPatternIndex; //host program is reserved
	unsigned char		reserved1[2];
} S_P1_TEST_STEP_HEADER;

typedef struct s_p1_test_step_reference_tag {
	long				refV;
	long				refI;
//	long				rangeI;

	//kjg081112 0x1006
	unsigned char		rangeI;
	unsigned char		reserved1[3];

	unsigned long		endT;
	long				endV;
		//at user_pattern : end_upper_v
		//at rest : branch_upper_v
	long				endI;
		//at user_pattern : end_lower_v
		//at rest : branch_lower_v
	long				endC;

	long				GotoCondition;
		//at rest : branch_upper_v step
	long				cycleCount;
		//at rest : branch_lower_v step
	
	long				endDeltaV;
	unsigned short		endSoc;
	unsigned short		reserved2;
	long				endP;
	long				endWattHour;

	long				accumulateGroupCycleCount;
	long				accumulateGroupCycleID;
	unsigned long		endCVTime;
	long				reserved3;
} S_P1_TEST_STEP_REFERENCE;

typedef struct s_p1_test_comp_cond_tag {
	long				lowerValue;
	long				upperValue;
	unsigned long		time;
} S_P1_TEST_COMP_COND;

typedef struct s_p1_test_delta_cond_tag {
	long				lowerValue;
	long				upperValue;
	unsigned long		time;
} S_P1_TEST_DELTA_COND;

typedef struct s_p1_test_record_cond_tag {
	unsigned long		time;
	long				deltaV;
	long				deltaI;
	long				deltaT; //temperature
	long				deltaP;
	long				reserved;
} S_P1_TEST_RECORD_COND;

typedef struct s_p1_test_edlc_cond_tag {
	long				capacitanceV1;
	long				capacitanceV2;
	unsigned long		startT_Z;
	unsigned long		endT_Z;
	unsigned long		startT_LC;
	unsigned long		endT_LC;
} S_P1_TEST_EDLC_COND;

typedef struct s_p1_test_grade_step_tag {
	unsigned char		gradeCode;
	unsigned char		reserved1;
	short int			reserved2;
	long				lowerValue;	//equal and upper(lowerValue <= x)
	long				upperValue;	//only lower(upperValue > x)
} S_P1_TEST_GRADE_STEP;

typedef struct s_p1_test_grade_cond_tag {
	unsigned char		item;
	unsigned char		gradeStepCount;
	short int			reserved1;

	S_P1_TEST_GRADE_STEP	gradeStep[MAX_P1_GRADE_STEP];
} S_P1_TEST_GRADE_COND;

typedef struct s_p1_test_cond_step_tag {
	S_P1_TEST_STEP_HEADER	header;
	S_P1_TEST_STEP_REFERENCE	reference[MAX_P1_SUB_STEP];
	S_P1_TEST_COMP_COND		compV[MAX_P1_COMP_POINT];
	S_P1_TEST_COMP_COND		compI[MAX_P1_COMP_POINT];
	S_P1_TEST_DELTA_COND	deltaV;
	S_P1_TEST_DELTA_COND	deltaI;
	S_P1_TEST_RECORD_COND	record;
	S_P1_TEST_EDLC_COND		edlc;
	S_P1_TEST_GRADE_COND	grade[MAX_P1_GRADE_ITEM];

	long				faultUpperV;
	long				faultLowerV;
	long				faultUpperI;
	long				faultLowerI;
	long				faultUpper_AmpareHour;
	long				faultLower_AmpareHour;
	/*kjgw long				faultUpper_Capacitance;
	long				faultLower_Capacitance;*/
	long				faultUpperZ;
	long				faultLowerZ;
	long				faultUpperTemp;
	long				faultLowerTemp;
	long				reserved1[2];
} S_P1_TEST_COND_STEP;

typedef struct s_p1_test_cond_user_pattern_tag {
	S_P1_TEST_STEP_HEADER	header;
	S_P1_TEST_STEP_REFERENCE	reference[MAX_P1_SUB_STEP];
	S_P1_TEST_RECORD_COND	record;

	long				faultUpperV;
	long				faultLowerV;
	long				faultUpperI;
	long				faultLowerI;
	long				faultUpper_AmpareHour;
	long				faultLower_AmpareHour;
	/*kjgw long				faultUpper_Capacitance;
	long				faultLower_Capacitance;*/
	long				faultUpperZ;
	long				faultLowerZ;
	long				faultUpperTemp;
	long				faultLowerTemp;
	long				reserved1[2];

	//insert user pattern data
} S_P1_TEST_COND_USER_PATTERN;

typedef struct s_p1_test_cond_user_pattern_data_tag {
	long				t_val;
	long				cmd_val;
} S_P1_TEST_COND_USER_PATTERN_DATA;

typedef struct s_p1_test_condition_tag {
	S_P1_TEST_COND_HEADER	header;
	S_P1_TEST_COND_SAFETY	safety;
   	S_P1_TEST_COND_STEP	step[MAX_P1_STEP];
	S_P1_TEST_COND_USER_PATTERN	pattern[MAX_P1_STEP_USER_PATTERN];
	S_P1_TEST_COND_USER_PATTERN_DATA
			pattern_data[MAX_P1_STEP_USER_PATTERN][MAX_P1_USER_PATTERN_DATA];
	short int			stepCount;
} S_P1_TEST_CONDITION;

typedef struct s_p1_response_tag {
	int					cmd;
	int					code;
} S_P1_RESPONSE;

typedef struct s_p1_rcv_cmd_module_info_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_MODULE_INFO_REQUEST;

typedef struct s_p1_rcv_cmd_module_set_data_tag {
	S_P1_CMD_HEADER		header;
	unsigned char		connection_retry;
	unsigned char		line_mode;
	unsigned char		control_mode;
	unsigned char		working_mode;
	unsigned int		auto_report_interval;
	unsigned int		data_save_interval;
	unsigned int		reserved1[16];
} S_P1_RCV_CMD_MODULE_SET_DATA;

typedef struct s_p1_cmd_control_tag {
	long				stepNo;
	long				cycleNo;
	long				reserved1[6];
} S_P1_CMD_CONTROL;

typedef struct s_p1_rcv_cmd_run_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CMD_CONTROL	control;
} S_P1_RCV_CMD_RUN;

typedef struct s_p1_rcv_cmd_stop_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CMD_CONTROL	control;
} S_P1_RCV_CMD_STOP;

typedef struct s_p1_rcv_cmd_pause_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CMD_CONTROL	control;
} S_P1_RCV_CMD_PAUSE;

typedef struct s_p1_rcv_cmd_continue_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CONTINUE;

typedef struct s_p1_rcv_cmd_next_step_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_NEXT_STEP;

typedef struct s_p1_rcv_cmd_reset_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_RESET;

typedef struct s_p1_rcv_cmd_testcond_start_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_HEADER	testCondHeader;
} S_P1_RCV_CMD_TESTCOND_START;

typedef struct s_p1_rcv_cmd_testcond_safety_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_SAFETY	safety;
} S_P1_RCV_CMD_TESTCOND_SAFETY;

typedef struct s_p1_rcv_cmd_testcond_step_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_STEP	testCondStep;
} S_P1_RCV_CMD_TESTCOND_STEP;

typedef struct s_p1_rcv_cmd_testcond_end_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_TESTCOND_END;

typedef struct s_p1_rcv_cmd_step_cond_request_tag {
	S_P1_CMD_HEADER		header;
	long				stepNo;
	long				reserved1[3];
} S_P1_RCV_CMD_STEP_COND_REQUEST;

typedef struct s_p1_rcv_cmd_step_cond_update_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_STEP_COND_UPDATE;

typedef struct s_p1_rcv_cmd_safety_cond_request_tag {
	S_P1_CMD_HEADER		header;
	long				stepNo;
	long				reserved1[3];
} S_P1_RCV_CMD_SAFETY_COND_REQUEST;

typedef struct s_p1_rcv_cmd_safety_cond_update_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_SAFETY_COND_UPDATE;

typedef struct s_p1_rcv_cmd_reset_reserved_cmd_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_RESET_RESERVED_CMD;

typedef struct s_p1_rcv_cmd_testcond_user_pattern_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_USER_PATTERN	testCondUserPattern;
} S_P1_RCV_CMD_TESTCOND_USER_PATTERN;

typedef struct s_p1_rcv_cmd_response_tag {
	S_P1_CMD_HEADER		header;
	S_P1_RESPONSE		response;
} S_P1_RCV_CMD_RESPONSE;

typedef struct s_p1_rcv_cmd_cali_meter_connect_tag {
	S_P1_CMD_HEADER		header;
	long				type;
} S_P1_RCV_CMD_CALI_METER_CONNECT;

typedef struct s_p1_cali_point_tag {
	unsigned char		setPointNum;
	unsigned char		checkPointNum;
	unsigned char		reserved1[2];
	long				setPoint[MAX_CALI_POINT];
	long				checkPoint[MAX_CALI_POINT];
} S_P1_CALI_POINT;

typedef struct s_p1_cali_tmp_cond_tag {
	int					type;
	int					range;
	int					mode;
	S_P1_CALI_POINT		point;
} S_P1_CALI_TMP_COND;

typedef struct s_p1_rcv_cmd_cali_start_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_TMP_COND	tmpCond;
} S_P1_RCV_CMD_CALI_START;

typedef struct s_p1_rcv_cmd_cali_update_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CALI_UPDATE;

typedef struct s_p1_rcv_cmd_comm_check_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_COMM_CHECK;

typedef struct s_p1_rcv_cmd_comm_check_reply_tag {
	S_P1_CMD_HEADER		header;
	char				result[2];
	char				sent_cmd[4];
} S_P1_RCV_CMD_COMM_CHECK_REPLY;

typedef struct s_p1_ch_attribute_tag {
	unsigned char		chNo_master;	//1base
	unsigned char		chNo_slave[3];	//1base
	unsigned char		opType;			//0:independent, 1:parallel
	unsigned char		reserved1[3];
} S_P1_CH_ATTRIBUTE;

typedef struct s_p1_rcv_cmd_ch_attribute_set_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CH_ATTRIBUTE	attr[MAX_CH_PER_MODULE];
} S_P1_RCV_CMD_CH_ATTRIBUTE_SET;

typedef struct s_p1_rcv_cmd_ch_attribute_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CH_ATTRIBUTE_REQUEST;

typedef struct s_p1_aux_set_data_tag {
	unsigned char		chNo;			//1base : machine channel number
	unsigned char		reserved1[3];
	short int			auxChNo;		//1base : aux channel number
	short int			auxType;		//0:temperature, 1:v
	char				name[MAX_AUX_NAME_SIZE];
	long				fault_upper;
	long				fault_lower;
	long				end_upper;
	long				end_lower;
	long				reserved2[2];
} S_P1_AUX_SET_DATA;

typedef struct s_p1_rcv_cmd_aux_set_tag {
	S_P1_CMD_HEADER		header;
	S_P1_AUX_SET_DATA	auxSetData[MAX_AUX_DATA];
} S_P1_RCV_CMD_AUX_SET;

typedef struct s_p1_can_receive_common_data_tag {
	unsigned char		can_baudrate;	//0:125K, 1:250K, 2:500K, 3:1M, 4:User
	unsigned char		extended_id;	//0:unused, 1:used
	unsigned char		reserved1[2];

	long				controller_canID;
	long				mask[2];
	long				filter[6];

	float				cell_cv_value;
	long				reserved2[2];
} S_P1_CAN_RECEIVE_COMMON_DATA;

typedef struct s_p1_can_receive_normal_data_tag {
	unsigned char		canType;		//0:unused, 1:master, 2:slave
	unsigned char		byte_order;		//0:intel, 1:motolora
	unsigned char		data_type;	//0:unsigned, 1:signed, 2:float, 3:string
	unsigned char		data_attribute; //cell_cv_flag;

	float				factor;
	short int			startBit;
	short int			bitCount;

	long				canID;			//hex value
	char				name[MAX_CAN_NAME_SIZE];
	float				fault_upper;
	float				fault_lower;
	float				end_upper;
	float				end_lower;

	//kjgw080822 long				reserved1;
	unsigned char		user_control;
	unsigned char		tmp_user_control;
	unsigned char		reserved1[2];

	//kjg081112 0x1006
	float				offset;
	float				reserved2;
} S_P1_CAN_RECEIVE_NORMAL_DATA;

typedef struct s_p1_can_receive_set_data_tag {
	S_P1_CAN_RECEIVE_COMMON_DATA	commonData[MAX_CH_PER_MODULE][MAX_CAN_TYPE];
	S_P1_CAN_RECEIVE_NORMAL_DATA	normalData[MAX_CH_PER_MODULE][MAX_CAN_DATA];
} S_P1_CAN_RECEIVE_SET_DATA;

typedef struct s_p1_rcv_cmd_can_recieve_set_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CAN_RECEIVE_SET_DATA	canReceiveSetData;
} S_P1_RCV_CMD_CAN_RECEIVE_SET;

typedef struct s_p1_can_transmit_common_data_tag {
	unsigned char		can_baudrate;	//0:125K, 1:250K, 2:500K, 3:1M, 4:User
	unsigned char		extended_id;	//0:unused, 1:used
	unsigned char		reserved1[2];

	long				controller_canID;
	float				inverter_capacitor_v;
	float				mcu_temp;
} S_P1_CAN_TRANSMIT_COMMON_DATA;

typedef struct s_p1_can_transmit_normal_data_tag {
	unsigned char		canType;		//0:unused, 1:master, 2:slave
	unsigned char		byte_order;		//0:intel, 1:motolora
	unsigned char		data_type;	//0:unsigned, 1:signed, 2:float, 3:string
	unsigned char		data_attribute;	//0bit(0:none 1:inverter_capacitor_v)
										//1bit(0:none 1:mcu_temp)

	float				factor;
	float				default_value;
	short int			startBit;
	short int			bitCount;

	long				canID;			//hex value
	long				send_period;
	char				name[MAX_CAN_NAME_SIZE];

	unsigned char		user_control;		//only sbc used
	unsigned char		tmp_user_control;	//only sbc used
	unsigned char		reserved1[2];

	//kjg081112 0x1006
	float				offset;
	float				reserved2;
} S_P1_CAN_TRANSMIT_NORMAL_DATA;

typedef struct s_p1_can_transmit_set_data_tag {
	S_P1_CAN_TRANSMIT_COMMON_DATA	commonData[MAX_CH_PER_MODULE][MAX_CAN_TYPE];
	S_P1_CAN_TRANSMIT_NORMAL_DATA	normalData[MAX_CH_PER_MODULE][MAX_CAN_DATA];
} S_P1_CAN_TRANSMIT_SET_DATA;

typedef struct s_p1_rcv_cmd_can_transmit_set_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CAN_TRANSMIT_SET_DATA	canTransmitSetData;
} S_P1_RCV_CMD_CAN_TRANSMIT_SET;

typedef struct s_p1_rcv_cmd_aux_info_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_AUX_INFO_REQUEST;

typedef struct s_p1_rcv_cmd_can_receive_info_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CAN_RECEIVE_INFO_REQUEST;

typedef struct s_p1_rcv_cmd_real_time_reply_tag {
	S_P1_CMD_HEADER		header;
	char				real_time[24];
} S_P1_RCV_CMD_REAL_TIME_REPLY;

typedef struct s_p1_rcv_cmd_bms_communication_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_BMS_COMM_REQUEST;

typedef struct s_p1_rcv_cmd_can_transmit_info_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_RCV_CMD_CAN_TRANSMIT_INFO_REQUEST;

typedef struct s_p1_send_cmd_ch_attribute_reply_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CH_ATTRIBUTE	attr[MAX_CH_PER_MODULE];
} S_P1_SEND_CMD_CH_ATTRIBUTE_REPLY;

typedef struct s_p1_send_cmd_aux_info_reply_tag {
	S_P1_CMD_HEADER		header;
	short int			installedTemp;
	short int			installedAuxV;
	short int			reserved1[2];
	S_P1_AUX_SET_DATA	auxSetData[MAX_AUX_DATA];
} S_P1_SEND_CMD_AUX_INFO_REPLY;

typedef struct s_p1_send_cmd_can_receive_info_reply_tag {
	S_P1_CMD_HEADER		header;
	short int			canReceiveDataCount[MAX_CH_PER_MODULE];
	S_P1_CAN_RECEIVE_SET_DATA	canReceiveSetData;
} S_P1_SEND_CMD_CAN_RECEIVE_INFO_REPLY;

typedef struct s_p1_send_cmd_can_transmit_info_reply_tag {
	S_P1_CMD_HEADER		header;
	short int			canTransmitDataCount[MAX_CH_PER_MODULE];
	S_P1_CAN_TRANSMIT_SET_DATA	canTransmitSetData;
} S_P1_SEND_CMD_CAN_TRANSMIT_INFO_REPLY;

typedef struct s_p1_ch_data_tag {
	unsigned char		ch;
	unsigned char		state;
	unsigned char		stepType;
	unsigned char		stepMode;

	unsigned char		select;
	unsigned char		code;
	unsigned char		stepNo;
	unsigned char		grade;

	long				Vsens;
	long				Isens;
	long				charge_AmpareHour;
	long				discharge_AmpareHour;
	long				capacitance;
	long				watt;
	long				charge_WattHour;
	long				discharge_WattHour;
	unsigned long		runTime;
	unsigned long		totalRunTime;
	long				z;

	unsigned char		reservedCmd;	//0:normal, 1:stop, 2:pause
	unsigned char		reserved1[3];
	long				reserved2[4];	//for loop in loop reserved

	short int			auxDataCount;
	short int			canReceiveDataCount;

	unsigned long		totalCycle;
	unsigned long		currentCycle;
	unsigned long		accumulateGroupCycle;

	long				avgV;
	long				avgI;
	long				resultIndex;

	unsigned long		cvTime;
	long				realDate;
	long				realClock;
} S_P1_CH_DATA;

typedef struct s_p1_send_cmd_ch_data_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CH_DATA		chData[MAX_CH_PER_MODULE];
} S_P1_SEND_CMD_CH_DATA;

typedef struct s_p1_aux_data_tag {
	short int			auxChNo;		//1base
	short int			auxType;		//0:temperature, 1:v
	long				val;
} S_P1_AUX_DATA;

typedef union u_p1_can_val_tag {
	unsigned long		ul_val[2];
	long				l_val[2];
	float				f_val[2];
	unsigned char		uc_val[8];
	char				c_val[8];
} U_P1_CAN_VAL;

typedef struct s_p1_can_data_tag {
	unsigned char		canType;		//0:unused, 1:master, 2:slave
	unsigned char		data_type;	//0:unsigned, 1:signed, 2:float, 3:string
	unsigned char		reserved1[2];

	U_P1_CAN_VAL		val;
} S_P1_CAN_DATA;

typedef struct s_p1_send_cmd_ch_data2_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CH_DATA		chData;
	S_P1_AUX_DATA		auxData[MAX_AUX_DATA];
	S_P1_CAN_DATA		canData[MAX_CAN_DATA];
} S_P1_SEND_CMD_CH_DATA2;

typedef struct s_p1_module_info_tag {
	unsigned int		group_id;
	unsigned int		systemType;
	unsigned int		protocol_version;
	char				modelName[128];
	unsigned int		osVersion;
	unsigned short int	voltage_range;
	unsigned short int	current_range;
	unsigned int		voltage_spec[5];
	unsigned int		current_spec[5];
	unsigned char		reserved1[8];

	unsigned short int	installedBd;
	unsigned short int	chPerBd;
	unsigned int		installedCh;
	unsigned int		totalJig;
	unsigned int		BdinJig[16];
	int					reserved2[4];	
} S_P1_MODULE_INFO;

typedef struct s_p1_send_cmd_module_info_reply_tag {
	S_P1_CMD_HEADER		header;
	S_P1_MODULE_INFO	md_info;
} S_P1_SEND_CMD_MODULE_INFO_REPLY;

typedef struct s_p1_send_cmd_response_tag {
	S_P1_CMD_HEADER		header;
	S_P1_RESPONSE		response;
} S_P1_SEND_CMD_RESPONSE;

typedef struct s_p1_send_cmd_meter_connect_reply_tag {
	S_P1_CMD_HEADER		header;
	long				state;
} S_P1_SEND_CMD_METER_CONNECT_REPLY;

typedef struct s_p1_send_cmd_cali_start_reply_tag {
	S_P1_CMD_HEADER		header;
	S_P1_RESPONSE		response;
} S_P1_SEND_CMD_CALI_START_REPLY;

typedef struct s_p1_cali_normal_result_tag {
	int					type;
	unsigned char		range;
	unsigned char		setPointNum;
	unsigned char		checkPointNum;
	unsigned char		ch;
	long				setPointAD[MAX_CALI_POINT];
	long				setPointDVM[MAX_CALI_POINT];
	long				checkPointAD[MAX_CALI_POINT];
	long				checkPointDVM[MAX_CALI_POINT];
} S_P1_CALI_NORMAL_RESULT;

typedef struct s_p1_cali_check_result_tag {
	int					type;
	unsigned char		range;
	unsigned char		reserved1;
	unsigned char		checkPointNum;
	unsigned char		ch;
	long				checkPointAD[MAX_CALI_POINT];
	long				checkPointDVM[MAX_CALI_POINT];
} S_P1_CALI_CHECK_RESULT;

typedef struct s_p1_send_cmd_cali_normal_result_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_NORMAL_RESULT	result;
} S_P1_SEND_CMD_CALI_NORMAL_RESULT;

typedef struct s_p1_send_cmd_cali_check_result_tag {
	S_P1_CMD_HEADER		header;
	S_P1_CALI_CHECK_RESULT	result;
} S_P1_SEND_CMD_CALI_CHECK_RESULT;

typedef struct s_p1_send_cmd_comm_check_reply_tag {
	S_P1_CMD_HEADER		header;
} S_P1_SEND_CMD_COMM_CHECK_REPLY;

typedef struct s_p1_send_cmd_comm_check_tag {
	S_P1_CMD_HEADER		header;
} S_P1_SEND_CMD_COMM_CHECK;

typedef struct s_p1_send_cmd_emg_status_tag {
	S_P1_CMD_HEADER		header;
	long				code;
	long				val;
} S_P1_SEND_CMD_EMG_STATUS;

typedef struct s_p1_send_cmd_step_cond_reply_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_STEP	testCondStep;
} S_P1_SEND_CMD_STEP_COND_REPLY;

typedef struct s_p1_send_cmd_safety_cond_reply_tag {
	S_P1_CMD_HEADER		header;
	S_P1_TEST_COND_SAFETY	safety;
} S_P1_SEND_CMD_SAFETY_COND_REPLY;

typedef struct s_p1_send_cmd_real_time_request_tag {
	S_P1_CMD_HEADER		header;
} S_P1_SEND_CMD_REAL_TIME_REQUEST;

typedef struct s_p1_send_cmd_bms_communication_reply_tag {
	S_P1_CMD_HEADER		header;
	float				value[4];
} S_P1_SEND_CMD_BMS_COMM_REPLY;

typedef struct s_p1_misc_tag {
  	int    				send_socket;
   	int    				receive_socket;
   	int    				network_socket; //common socket

	long				timer;
	long				network_timer;
	unsigned long		cmd_serial;

	int					CO_No;
	int					psSignal;
	int					chInGroup;
	int					chOffset;
	int					processPointer;

	long				sent_monitor_data_time;
	long				sent_real_time_request;
} S_P1_MISC;
#endif
